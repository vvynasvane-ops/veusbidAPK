package com.veus.veusbid.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import android.app.Activity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.GoogleAuthProvider;
import com.veus.veusbid.FirebaseConfig;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.veus.veusbid.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/** Launcher screen: email/password log in, sign up, password reset. Forwards if already signed in. */
public class AuthActivity extends BaseActivity {

    private FirebaseAuth auth;
    private boolean signUp = false;

    private TextInputLayout tilName;
    private TextInputLayout tilConfirm;
    private TextInputEditText etName;
    private TextInputEditText etEmail;
    private TextInputEditText etPassword;
    private TextInputEditText etConfirm;
    private TextView errorView;
    private MaterialButton btnSubmit;
    private MaterialButton btnToggle;
    private MaterialButton btnForgot;
    private ProgressBar progress;
    private MaterialButton btnGoogle;
    private GoogleSignInClient googleClient;

    private static final String TAG = "VeusBidAuth";
    private String discoveredWebClientId;
    private boolean browserFallback = false;

    private final ActivityResultLauncher<Intent> googleLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                Intent data = result.getData();
                if (data == null) {
                    // Chooser closed with no status. Happens on a real back-out AND when the app's SHA-1 isn't
                    // registered, so don't fail silently: say what happened and offer the browser route.
                    setBusy(false);
                    Log.w(TAG, "Google chooser returned no data, resultCode=" + result.getResultCode());
                    showError("Google sign-in closed without a result. If you didn't cancel it, tap \"Continue with Google\" "
                            + "again - the browser sign-in will be used.");
                    if (result.getResultCode() != Activity.RESULT_OK) browserFallback = true;
                    return;
                }
                try {
                    // Read the status even when resultCode is CANCELED: DEVELOPER_ERROR (10) arrives that way.
                    GoogleSignInAccount acct = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                    String token = acct.getIdToken();
                    if (token == null) {
                        Log.e(TAG, "No ID token returned");
                        browserGoogleSignIn("Google didn't return an ID token.");
                        return;
                    }
                    firebaseAuthWithGoogle(token);
                } catch (ApiException e) {
                    Log.e(TAG, "Google sign-in ApiException code=" + e.getStatusCode(), e);
                    if (e.getStatusCode() == 12501 || e.getStatusCode() == 7) {
                        setBusy(false);
                        showError(googleError(e));
                    } else {
                        // Misconfiguration (10), 12500, etc: tell the user why, then try the browser route.
                        browserGoogleSignIn(googleError(e));
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) {
            goMain();
            return;
        }
        setContentView(R.layout.activity_auth);

        tilName = findViewById(R.id.til_name);
        tilConfirm = findViewById(R.id.til_confirm);
        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        etConfirm = findViewById(R.id.et_confirm);
        errorView = findViewById(R.id.auth_error);
        btnSubmit = findViewById(R.id.btn_submit);
        btnToggle = findViewById(R.id.btn_toggle);
        btnForgot = findViewById(R.id.btn_forgot);
        progress = findViewById(R.id.auth_progress);
        btnGoogle = findViewById(R.id.btn_google);
        findViewById(R.id.starfield).setVisibility(
                com.veus.veusbid.util.Appearance.starfield(this) ? View.VISIBLE : View.GONE);
        btnGoogle.setOnClickListener(v -> startGoogleSignIn());

        btnToggle.setOnClickListener(v -> {
            signUp = !signUp;
            applyMode();
        });
        btnSubmit.setOnClickListener(v -> submit());
        btnForgot.setOnClickListener(v -> sendReset());
        applyMode();
    }

    private void applyMode() {
        tilName.setVisibility(signUp ? View.VISIBLE : View.GONE);
        tilConfirm.setVisibility(signUp ? View.VISIBLE : View.GONE);
        btnForgot.setVisibility(signUp ? View.GONE : View.VISIBLE);
        btnSubmit.setText(signUp ? "Create account" : "Log in");
        btnToggle.setText(signUp ? "Already a member? Log in" : "New here? Create an account");
        showError(null);
    }

    private String text(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private void submit() {
        final String email = text(etEmail);
        final String password = etPassword.getText() == null ? "" : etPassword.getText().toString();
        final String name = text(etName);

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showError("Enter a valid email address.");
            return;
        }
        if (password.length() < 6) {
            showError("Password must be at least 6 characters.");
            return;
        }
        if (signUp) {
            if (TextUtils.isEmpty(name)) {
                showError("Pick a display name.");
                return;
            }
            String confirm = etConfirm.getText() == null ? "" : etConfirm.getText().toString();
            if (!password.equals(confirm)) {
                showError("Passwords don't match.");
                return;
            }
        }
        showError(null);
        setBusy(true);

        if (signUp) {
            auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
                if (!task.isSuccessful() || task.getResult() == null || task.getResult().getUser() == null) {
                    setBusy(false);
                    showError(friendly(task.getException()));
                    return;
                }
                final FirebaseUser user = task.getResult().getUser();
                UserProfileChangeRequest req = new UserProfileChangeRequest.Builder().setDisplayName(name).build();
                user.updateProfile(req).addOnCompleteListener(t -> ensureProfile(user, name));
            });
        } else {
            auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
                if (!task.isSuccessful() || task.getResult() == null || task.getResult().getUser() == null) {
                    setBusy(false);
                    showError(friendly(task.getException()));
                    return;
                }
                ensureProfile(task.getResult().getUser(), null);
            });
        }
    }

    /** Creates users/{uid} if it doesn't exist yet (new sign-up, or a deleted/missing profile). */
    private void ensureProfile(final FirebaseUser user, final String displayName) {
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("users").document(user.getUid()).get().addOnCompleteListener(task -> {
            DocumentSnapshot snap = task.isSuccessful() ? task.getResult() : null;
            if (snap != null && snap.exists()) {
                goMain();
                return;
            }
            Map<String, Object> pref = new HashMap<>();
            pref.put("priceMin", null);
            pref.put("priceMax", null);
            pref.put("category", "");
            pref.put("conditions", new ArrayList<String>());

            Map<String, Object> data = new HashMap<>();
            String nm = !TextUtils.isEmpty(displayName) ? displayName
                    : (user.getDisplayName() != null && !user.getDisplayName().isEmpty()
                    ? user.getDisplayName() : "New member");
            data.put("name", nm);
            data.put("photoURL", "");
            data.put("phone", "");
            data.put("showOnlineStatus", true);
            data.put("savedItems", new ArrayList<String>());
            data.put("blockedUsers", new ArrayList<String>());
            data.put("preferences", pref);
            data.put("createdAt", System.currentTimeMillis());
            db.collection("users").document(user.getUid()).set(data)
                    .addOnCompleteListener(t -> {
                        if (!t.isSuccessful()) {
                            Toast.makeText(this, "Signed in, but your profile couldn't be created yet. It will retry.",
                                    Toast.LENGTH_LONG).show();
                        }
                        goMain();
                    });
        });
    }

    // ---------------- Google sign-in ----------------
    // Strategy: (1) native Google account chooser; the Web client ID is taken from google-services.json,
    // FirebaseConfig, or - if neither exists - discovered from the Firebase project at runtime.
    // (2) if the native route fails (usually an unregistered SHA-1) fall back to Firebase's browser-based
    // Google flow, which needs no Android OAuth client. The app shows its own SHA-1 so it can be registered.

    private String webClientId() {
        int id = getResources().getIdentifier("default_web_client_id", "string", getPackageName());
        if (id != 0) return getString(id);
        if (!FirebaseConfig.WEB_CLIENT_ID.isEmpty()) return FirebaseConfig.WEB_CLIENT_ID;
        return discoveredWebClientId == null ? "" : discoveredWebClientId;
    }

    private void startGoogleSignIn() {
        showError(null);
        setBusy(true);
        if (browserFallback) {
            browserFallback = false;
            browserGoogleSignIn(null);
            return;
        }
        if (!webClientId().isEmpty()) {
            launchNativeGoogle(webClientId());
            return;
        }
        // No client ID configured: ask Firebase for the project's Google web client ID.
        new Thread(() -> {
            final String found = discoverWebClientId();
            runOnUiThread(() -> {
                if (found != null) {
                    discoveredWebClientId = found;
                    launchNativeGoogle(found);
                } else {
                    browserGoogleSignIn("Couldn't auto-detect the Google client ID.");
                }
            });
        }).start();
    }

    private void launchNativeGoogle(String clientId) {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(clientId)
                .requestEmail()
                .build();
        googleClient = GoogleSignIn.getClient(this, gso);
        // Sign out first so the account chooser always appears (lets people pick a different account).
        googleClient.signOut().addOnCompleteListener(t -> googleLauncher.launch(googleClient.getSignInIntent()));
    }

    /** Reads the Google OAuth web client_id out of the auth URI Firebase hands back for provider google.com. */
    private String discoverWebClientId() {
        java.net.HttpURLConnection c = null;
        try {
            java.net.URL url = new java.net.URL(
                    "https://identitytoolkit.googleapis.com/v1/accounts:createAuthUri?key=" + FirebaseConfig.API_KEY);
            c = (java.net.HttpURLConnection) url.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            String body = "{\"providerId\":\"google.com\",\"continueUri\":\"https://" + FirebaseConfig.PROJECT_ID
                    + ".firebaseapp.com/__/auth/handler\"}";
            c.getOutputStream().write(body.getBytes("UTF-8"));
            int code = c.getResponseCode();
            java.io.InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[2048];
            int n;
            while (in != null && (n = in.read(buf)) > 0) out.write(buf, 0, n);
            String resp = out.toString("UTF-8");
            if (code >= 400) { Log.e(TAG, "createAuthUri HTTP " + code + ": " + resp); return null; }
            String authUri = new org.json.JSONObject(resp).optString("authUri", "");
            String cid = android.net.Uri.parse(authUri).getQueryParameter("client_id");
            Log.i(TAG, "Discovered web client id: " + cid);
            return cid == null || cid.isEmpty() ? null : cid;
        } catch (Exception e) {
            Log.e(TAG, "discoverWebClientId failed", e);
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Firebase's browser-based Google flow (Custom Tab). Works without an Android OAuth client. */
    private void browserGoogleSignIn(String reasonNativeFailed) {
        setBusy(true);
        if (reasonNativeFailed != null) {
            showError(reasonNativeFailed + "\nTrying browser sign-in instead...");
        }
        com.google.firebase.auth.OAuthProvider.Builder b = com.google.firebase.auth.OAuthProvider.newBuilder("google.com");
        b.setScopes(java.util.Arrays.asList("email", "profile"));
        b.addCustomParameter("prompt", "select_account");
        com.google.android.gms.tasks.Task<com.google.firebase.auth.AuthResult> pending = auth.getPendingAuthResult();
        com.google.android.gms.tasks.Task<com.google.firebase.auth.AuthResult> task =
                pending != null ? pending : auth.startActivityForSignInWithProvider(this, b.build());
        task.addOnSuccessListener(r -> {
            if (r.getUser() == null) { setBusy(false); showError("Sign-in returned no user."); return; }
            ensureProfile(r.getUser(), null);
        }).addOnFailureListener(e -> {
            Log.e(TAG, "Browser Google sign-in failed", e);
            setBusy(false);
            String sha = signingSha1();
            copyToClipboard(sha);
            showError("Google sign-in failed: " + friendly(e)
                    + "\n\nFix: Firebase console -> Project settings -> your Android app (com.veus.veusbid) -> Add fingerprint, "
                    + "paste this app's SHA-1 (already copied to your clipboard):\n" + sha
                    + "\nAlso make sure Authentication -> Sign-in method -> Google is Enabled.");
        });
    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential cred = GoogleAuthProvider.getCredential(idToken, null);
        auth.signInWithCredential(cred).addOnCompleteListener(task -> {
            if (!task.isSuccessful() || task.getResult() == null || task.getResult().getUser() == null) {
                Log.e(TAG, "Firebase signInWithCredential failed", task.getException());
                setBusy(false);
                showError(friendly(task.getException()));
                return;
            }
            ensureProfile(task.getResult().getUser(), null);
        });
    }

    private String googleError(ApiException e) {
        String sha = signingSha1();
        switch (e.getStatusCode()) {
            case 12501:
                return "Google sign-in was cancelled.";
            case 10:
                copyToClipboard(sha);
                return "Google native sign-in rejected this build (DEVELOPER_ERROR). SHA-1 of this build: " + sha;
            case 7:
                return "Network error - check your connection and try again.";
            default:
                return "Google sign-in failed (code " + e.getStatusCode() + ").";
        }
    }

    /** The SHA-1 of the key this APK is signed with: exactly what Firebase wants under 'Add fingerprint'. */
    private String signingSha1() {
        try {
            android.content.pm.PackageManager pm = getPackageManager();
            android.content.pm.Signature[] sigs;
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                android.content.pm.PackageInfo pi = pm.getPackageInfo(getPackageName(),
                        android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES);
                sigs = pi.signingInfo.getApkContentsSigners();
            } else {
                @SuppressWarnings("deprecation")
                android.content.pm.PackageInfo pi = pm.getPackageInfo(getPackageName(),
                        android.content.pm.PackageManager.GET_SIGNATURES);
                @SuppressWarnings("deprecation")
                android.content.pm.Signature[] s2 = pi.signatures;
                sigs = s2;
            }
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-1");
            byte[] d = md.digest(sigs[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < d.length; i++) {
                if (i > 0) sb.append(':');
                sb.append(String.format("%02X", d[i]));
            }
            Log.i(TAG, "App SHA-1: " + sb);
            return sb.toString();
        } catch (Exception ex) {
            return "(could not read SHA-1: " + ex.getMessage() + ")";
        }
    }

    private void copyToClipboard(String text) {
        try {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("SHA-1", text));
        } catch (Exception ignored) { }
    }

    private void sendReset() {
        String email = text(etEmail);
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showError("Type your email above first, then tap Forgot password.");
            return;
        }
        setBusy(true);
        auth.sendPasswordResetEmail(email).addOnCompleteListener(task -> {
            setBusy(false);
            if (task.isSuccessful()) {
                showError(null);
                Toast.makeText(this, "Reset email sent - check your inbox.", Toast.LENGTH_LONG).show();
            } else {
                showError(friendly(task.getException()));
            }
        });
    }

    private void setBusy(boolean busy) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        btnGoogle.setEnabled(!busy);
        btnSubmit.setEnabled(!busy);
        btnToggle.setEnabled(!busy);
        btnForgot.setEnabled(!busy);
    }

    private void showError(String msg) {
        if (msg == null) {
            errorView.setVisibility(View.GONE);
        } else {
            errorView.setText(msg);
            errorView.setVisibility(View.VISIBLE);
        }
    }

    static String friendly(Exception e) {
        if (e instanceof FirebaseAuthWeakPasswordException) return "That password is too weak - try a longer one.";
        if (e instanceof FirebaseAuthUserCollisionException) return "An account with that email already exists.";
        if (e instanceof FirebaseAuthInvalidUserException) return "No account found for that email.";
        if (e instanceof FirebaseAuthInvalidCredentialsException) return "Wrong email or password.";
        if (e instanceof FirebaseNetworkException) return "Network error - check your connection and try again.";
        return e != null && e.getMessage() != null ? e.getMessage() : "Something went wrong. Try again.";
    }

    private void goMain() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
