package com.veus.veusbid.ui;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.veus.veusbid.util.Appearance;
import com.veus.veusbid.util.FontStyler;

/** Every screen extends this so palette / accent / radius / font / size apply everywhere. */
public abstract class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Appearance.applyTheme(this);
        super.onCreate(savedInstanceState);
        // Dark icons on light bars, light icons on dark bars (status + navigation).
        boolean light = Appearance.isLight(this);
        WindowInsetsControllerCompat wic = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        wic.setAppearanceLightStatusBars(light);
        wic.setAppearanceLightNavigationBars(light);
    }

    @Override
    public void onContentChanged() {
        super.onContentChanged();
        View content = findViewById(android.R.id.content);
        FontStyler.apply(content);
    }
}
