package com.veus.veusbid.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.veus.veusbid.R;
import com.veus.veusbid.data.Item;
import com.veus.veusbid.data.UserStore;
import com.veus.veusbid.util.Const;
import com.veus.veusbid.util.Currency;
import com.veus.veusbid.util.FontStyler;
import com.veus.veusbid.util.Ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class BrowseFragment extends Fragment implements AuctionAdapter.Callbacks, UserStore.Listener {

    private static final String[] SORTS = {
            "Ending soonest", "Newest", "Price: low to high", "Price: high to low", "Most bids"
    };

    /** Filter state kept in memory while the app is open. */
    private static final class Filters {
        String category = "";
        /** "" = any currency (prices compared after an approximate conversion), else an ISO code. */
        String currency = "";
        Double min = null;
        Double max = null;
        final List<String> conditions = new ArrayList<>();
        boolean endingSoon = false;
        boolean hasPhoto = false;
        boolean watchOnly = false;
        boolean includeEnded = false;

        boolean active() {
            return !category.isEmpty() || !currency.isEmpty() || min != null || max != null || !conditions.isEmpty()
                    || endingSoon || hasPhoto || watchOnly || includeEnded;
        }
    }

    private final List<Item> all = new ArrayList<>();
    private final Filters filters = new Filters();
    private int sortIndex = 0;
    private String query = "";
    private boolean loaded = false;
    private String loadError = null;

    private AuctionAdapter adapter;
    private TextView tvEmpty;
    private TextView tvSummary;
    private ListenerRegistration reg;
    private final Handler ticker = new Handler(Looper.getMainLooper());
    private int tickCount = 0;

    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            adapter.tick();
            tickCount++;
            // Drop auctions that just ended (when "include ended" is off).
            if (!filters.includeEnded && tickCount % 5 == 0) applyFilters();
            ticker.postDelayed(this, 1000);
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        return inflater.inflate(R.layout.fragment_browse, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        super.onViewCreated(view, state);
        tvEmpty = view.findViewById(R.id.tv_empty);
        tvSummary = view.findViewById(R.id.tv_summary);
        RecyclerView rv = view.findViewById(R.id.rv_items);
        adapter = new AuctionAdapter(this);
        rv.setLayoutManager(new GridLayoutManager(requireContext(), 2));
        rv.setAdapter(adapter);
        rv.setItemAnimator(null);

        TextInputEditText et = view.findViewById(R.id.et_search);
        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override
            public void afterTextChanged(Editable s) {
                query = s.toString().trim().toLowerCase(Locale.getDefault());
                applyFilters();
            }
        });

        Spinner sort = view.findViewById(R.id.spin_sort);
        ArrayAdapter<String> sa = new ArrayAdapter<>(requireContext(), R.layout.spinner_item, SORTS);
        sa.setDropDownViewResource(R.layout.spinner_dropdown);
        sort.setAdapter(sa);
        sort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                if (sortIndex != position) {
                    sortIndex = position;
                    applyFilters();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        view.findViewById(R.id.btn_filter).setOnClickListener(v -> showFilterDialog());
        FontStyler.apply(view);
    }

    @Override
    public void onStart() {
        super.onStart();
        UserStore.get().addListener(this);
        if (reg == null) {
            // orderBy on a single field needs no composite index. Live auctions sort first.
            Query q = FirebaseFirestore.getInstance().collection("items")
                    .orderBy("endTime", Query.Direction.DESCENDING).limit(300);
            reg = q.addSnapshotListener((QuerySnapshot snap, FirebaseFirestoreException e) -> {
                if (e != null) {
                    loadError = "Couldn't load auctions: " + e.getMessage();
                    loaded = true;
                    applyFilters();
                    return;
                }
                if (snap == null) return;
                all.clear();
                for (com.google.firebase.firestore.DocumentSnapshot d : snap.getDocuments()) {
                    all.add(Item.from(d));
                }
                loadError = null;
                loaded = true;
                applyFilters();
            });
        }
        applyFilters();
        ticker.removeCallbacks(tickRunnable);
        ticker.postDelayed(tickRunnable, 1000);
    }

    @Override
    public void onStop() {
        ticker.removeCallbacks(tickRunnable);
        UserStore.get().removeListener(this);
        super.onStop();
    }

    @Override
    public void onDestroyView() {
        if (reg != null) reg.remove();
        reg = null;
        super.onDestroyView();
    }

    @Override
    public void onUserChanged() {
        // Watchlist / block list changed: re-filter (and refresh hearts).
        if (adapter != null) applyFilters();
    }

    @Override
    public void onOpen(Item item) {
        Intent i = new Intent(requireContext(), ItemActivity.class);
        i.putExtra(Const.EXTRA_ITEM_ID, item.id);
        startActivity(i);
    }

    private void applyFilters() {
        if (adapter == null) return;
        UserStore us = UserStore.get();
        long now = System.currentTimeMillis();
        final String myCurrency = getContext() == null ? Currency.DEFAULT : Currency.preferred(getContext());
        List<Item> out = new ArrayList<>();
        for (Item it : all) {
            if (us.blocked.contains(it.ownerUid)) continue;
            if (!filters.includeEnded && it.endTime <= now) continue;
            if (!query.isEmpty()) {
                String hay = (it.title + " " + it.category + " " + it.description + " " + it.code)
                        .toLowerCase(Locale.getDefault());
                if (!hay.contains(query)) continue;
            }
            if (!filters.category.isEmpty() && !filters.category.equals(it.category)) continue;
            if (!filters.currency.isEmpty() && !filters.currency.equals(it.currency)) continue;
            double price = filters.currency.isEmpty()
                    ? Currency.convert(it.current(), it.currency, myCurrency)
                    : it.current();
            if (filters.min != null && price < filters.min) continue;
            if (filters.max != null && price > filters.max) continue;
            if (!filters.conditions.isEmpty() && !filters.conditions.contains(it.condition)) continue;
            if (filters.endingSoon && (it.endTime - now) > 60 * 60 * 1000L) continue;
            if (filters.hasPhoto && it.photos.isEmpty()) continue;
            if (filters.watchOnly && !us.saved.contains(it.id)) continue;
            out.add(it);
        }
        Collections.sort(out, comparator());
        adapter.submit(out);

        if (!loaded) {
            tvEmpty.setText("Loading auctions...");
            tvEmpty.setVisibility(View.VISIBLE);
        } else if (loadError != null) {
            tvEmpty.setText(loadError);
            tvEmpty.setVisibility(View.VISIBLE);
        } else if (out.isEmpty()) {
            tvEmpty.setText(all.isEmpty() ? "No auctions yet - be the first to list one."
                    : "Nothing matches your search or filters.");
            tvEmpty.setVisibility(View.VISIBLE);
        } else {
            tvEmpty.setVisibility(View.GONE);
        }
        tvSummary.setText(out.size() + (out.size() == 1 ? " auction" : " auctions")
                + (filters.active() ? " \u00b7 filters on" : ""));
    }

    private Comparator<Item> comparator() {
        switch (sortIndex) {
            case 1:
                return (a, b) -> Long.compare(b.createdAt, a.createdAt);
            case 2:
                return (a, b) -> Double.compare(Currency.toUsd(a.current(), a.currency), Currency.toUsd(b.current(), b.currency));
            case 3:
                return (a, b) -> Double.compare(Currency.toUsd(b.current(), b.currency), Currency.toUsd(a.current(), a.currency));
            case 4:
                return (a, b) -> Long.compare(b.bidCount, a.bidCount);
            default:
                return (a, b) -> Long.compare(a.endTime, b.endTime);
        }
    }

    private Double parse(TextInputEditText et) {
        String s = et.getText() == null ? "" : et.getText().toString().trim();
        if (s.isEmpty()) return null;
        try {
            return Double.valueOf(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void showFilterDialog() {
        View v = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_filter, null, false);
        final Spinner cat = v.findViewById(R.id.f_category);
        final Spinner cur = v.findViewById(R.id.f_currency);
        final TextView priceLabel = v.findViewById(R.id.f_price_label);
        final TextInputEditText min = v.findViewById(R.id.f_min);
        final TextInputEditText max = v.findViewById(R.id.f_max);
        final LinearLayout condBox = v.findViewById(R.id.f_conditions);
        final CheckBox ending = v.findViewById(R.id.f_ending);
        final CheckBox photo = v.findViewById(R.id.f_photo);
        final CheckBox watch = v.findViewById(R.id.f_watch);
        final CheckBox ended = v.findViewById(R.id.f_ended);

        List<String> cats = new ArrayList<>();
        cats.add("Any category");
        Collections.addAll(cats, Const.CATEGORIES);
        ArrayAdapter<String> ca = new ArrayAdapter<>(requireContext(), R.layout.spinner_item, cats);
        ca.setDropDownViewResource(R.layout.spinner_dropdown);
        cat.setAdapter(ca);
        int idx = cats.indexOf(filters.category);
        cat.setSelection(idx < 0 ? 0 : idx);

        final String mine = Currency.preferred(requireContext());
        List<String> curLabels = new ArrayList<>();
        curLabels.add("Any currency (converted to " + mine + ")");
        Collections.addAll(curLabels, Currency.labels());
        ArrayAdapter<String> cua = new ArrayAdapter<>(requireContext(), R.layout.spinner_item, curLabels);
        cua.setDropDownViewResource(R.layout.spinner_dropdown);
        cur.setAdapter(cua);
        cur.setSelection(filters.currency.isEmpty() ? 0 : Currency.indexOf(filters.currency) + 1);
        cur.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View view, int pos, long id) {
                priceLabel.setText(pos <= 0
                        ? "Price range (\u2248 " + Currency.get(mine).symbol.trim() + ", approximate)"
                        : "Price range (" + Currency.get(Currency.codeAt(pos - 1)).symbol.trim() + ")");
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });

        if (filters.min != null) min.setText(trimNum(filters.min));
        if (filters.max != null) max.setText(trimNum(filters.max));

        final List<CheckBox> condBoxes = new ArrayList<>();
        for (String c : Const.CONDITIONS) {
            CheckBox cb = new CheckBox(requireContext());
            cb.setText(c);
            cb.setTextColor(Ui.color(requireContext(), R.attr.vbText));
            cb.setChecked(filters.conditions.contains(c));
            condBox.addView(cb);
            condBoxes.add(cb);
        }
        ending.setChecked(filters.endingSoon);
        photo.setChecked(filters.hasPhoto);
        watch.setChecked(filters.watchOnly);
        ended.setChecked(filters.includeEnded);

        FontStyler.apply(v);
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Filters")
                .setView(v)
                .setPositiveButton("Apply", (d, w) -> {
                    int pos = cat.getSelectedItemPosition();
                    filters.category = pos <= 0 ? "" : Const.CATEGORIES[pos - 1];
                    int cpos = cur.getSelectedItemPosition();
                    filters.currency = cpos <= 0 ? "" : Currency.codeAt(cpos - 1);
                    filters.min = parse(min);
                    filters.max = parse(max);
                    filters.conditions.clear();
                    for (CheckBox cb : condBoxes) {
                        if (cb.isChecked()) filters.conditions.add(cb.getText().toString());
                    }
                    filters.endingSoon = ending.isChecked();
                    filters.hasPhoto = photo.isChecked();
                    filters.watchOnly = watch.isChecked();
                    filters.includeEnded = ended.isChecked();
                    applyFilters();
                })
                .setNeutralButton("Reset", (d, w) -> {
                    filters.category = "";
                    filters.currency = "";
                    filters.min = null;
                    filters.max = null;
                    filters.conditions.clear();
                    filters.endingSoon = false;
                    filters.hasPhoto = false;
                    filters.watchOnly = false;
                    filters.includeEnded = false;
                    applyFilters();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private static String trimNum(double d) {
        return d == Math.floor(d) ? String.valueOf((long) d) : String.valueOf(d);
    }
}
