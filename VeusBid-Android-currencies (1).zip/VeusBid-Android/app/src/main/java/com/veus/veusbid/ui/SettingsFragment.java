package com.veus.veusbid.ui;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;
import com.veus.veusbid.R;
import com.veus.veusbid.data.ProfileCache;
import com.veus.veusbid.data.UserStore;
import com.veus.veusbid.util.Appearance;
import com.veus.veusbid.util.FontStyler;
import com.veus.veusbid.util.Fmt;
import com.veus.veusbid.util.Ui;

import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import com.veus.veusbid.util.ImageUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SettingsFragment extends Fragment implements UserStore.Listener {

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private String pendingPhoto = null;     // data URL picked but maybe not saved yet
    private boolean fieldsFilled = false;

    private TextView tvEmail;
    private TextView tvInitial;
    private ImageView ivAvatar;
    private TextInputEditText etName;
    private TextInputEditText etPhone;
    private TextInputEditText etOldPw;
    private TextInputEditText etNewPw;
    private CheckBox cbOnline;
    private TextView tvBlocked;
    private MaterialButton btnUnblock;

    private final ActivityResultLauncher<String> photoPicker =
            registerForActivityResult(new ActivityResultContracts.GetContent(), this::onPhotoPicked);

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle state) {
        super.onViewCreated(v, state);
        tvEmail = v.findViewById(R.id.tv_email);
        tvInitial = v.findViewById(R.id.tv_avatar_initial);
        ivAvatar = v.findViewById(R.id.iv_avatar);
        etName = v.findViewById(R.id.et_name);
        etPhone = v.findViewById(R.id.et_phone);
        etOldPw = v.findViewById(R.id.et_old_pw);
        etNewPw = v.findViewById(R.id.et_new_pw);
        cbOnline = v.findViewById(R.id.cb_online);
        tvBlocked = v.findViewById(R.id.tv_blocked);
        btnUnblock = v.findViewById(R.id.btn_unblock);

        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        tvEmail.setText(u == null || u.getEmail() == null ? "" : u.getEmail());

        v.findViewById(R.id.btn_photo).setOnClickListener(x -> photoPicker.launch("image/*"));
        v.findViewById(R.id.btn_save).setOnClickListener(x -> saveProfile());
        v.findViewById(R.id.btn_change_pw).setOnClickListener(x -> changePassword());
        btnUnblock.setOnClickListener(x -> UserStore.get().clearBlocked());
        v.findViewById(R.id.btn_logout).setOnClickListener(x -> signOut());
        v.findViewById(R.id.btn_delete).setOnClickListener(x -> showDeleteDialog());
        fieldsFilled = false;
        bindFromStore();
        buildAppearance(v);
        FontStyler.apply(v);
    }

    @Override
    public void onStart() {
        super.onStart();
        UserStore.get().addListener(this);
        bindFromStore();
    }

    @Override
    public void onStop() {
        UserStore.get().removeListener(this);
        super.onStop();
    }

    @Override
    public void onDestroy() {
        io.shutdown();
        super.onDestroy();
    }

    @Override
    public void onUserChanged() {
        bindFromStore();
    }

    private void bindFromStore() {
        if (etName == null) return;
        UserStore us = UserStore.get();
        // Fill editable fields once so a live snapshot never overwrites what you're typing.
        if (!fieldsFilled && us.uid != null && !us.name.isEmpty()) {
            fieldsFilled = true;
            etName.setText(us.name);
            etPhone.setText(us.phone);
            cbOnline.setChecked(us.showOnlineStatus);
        }
        String photo = pendingPhoto != null ? pendingPhoto : us.photoUrl;
        tvInitial.setText(Fmt.initial(etName.getText() == null || etName.getText().length() == 0
                ? us.name : etName.getText().toString()));
        ImageUtil.load(ivAvatar, photo == null || photo.isEmpty() ? null : photo, 240);
        int n = us.blocked.size();
        tvBlocked.setText(n == 0 ? "You haven't blocked anyone." : "Blocked sellers: " + n);
        btnUnblock.setVisibility(n == 0 ? View.GONE : View.VISIBLE);
    }

    private void onPhotoPicked(Uri uri) {
        if (uri == null) return;
        final android.content.ContentResolver cr = requireContext().getContentResolver();
        io.execute(() -> {
            try {
                final String data = ImageUtil.uriToDataUrl(cr, uri, 256, 70);
                if (getActivity() == null) return;
                getActivity().runOnUiThread(() -> {
                    if (!isAdded()) return;
                    pendingPhoto = data;
                    bindFromStore();
                    toast("Photo ready \u2014 tap Save profile to keep it.");
                });
            } catch (Exception | OutOfMemoryError e) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> toast("Couldn't process that image."));
                }
            }
        });
    }

    private String text(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString();
    }

    private void saveProfile() {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;
        String name = text(etName).trim();
        if (name.isEmpty()) {
            toast("Display name can't be empty.");
            return;
        }
        Map<String, Object> m = new HashMap<>();
        m.put("name", name);
        m.put("phone", text(etPhone).trim());
        m.put("showOnlineStatus", cbOnline.isChecked());
        if (pendingPhoto != null) m.put("photoURL", pendingPhoto);
        FirebaseFirestore.getInstance().collection("users").document(uid).update(m)
                .addOnSuccessListener(v -> {
                    pendingPhoto = null;
                    ProfileCache.clear();
                    toast("Profile saved.");
                })
                .addOnFailureListener(e -> toast("Couldn't save: " + e.getMessage()));
    }

    private boolean hasPasswordProvider(FirebaseUser u) {
        for (UserInfo info : u.getProviderData()) {
            if (EmailAuthProvider.PROVIDER_ID.equals(info.getProviderId())) return true;
        }
        return false;
    }

    private void changePassword() {
        final FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null || u.getEmail() == null) return;
        if (!hasPasswordProvider(u)) {
            toast("This account signs in with Google - change its password from Google.");
            return;
        }
        String oldPw = text(etOldPw);
        final String newPw = text(etNewPw);
        if (oldPw.isEmpty()) {
            toast("Enter your current password.");
            return;
        }
        if (newPw.length() < 6) {
            toast("New password must be at least 6 characters.");
            return;
        }
        AuthCredential cred = EmailAuthProvider.getCredential(u.getEmail(), oldPw);
        u.reauthenticate(cred).addOnCompleteListener(t -> {
            if (!t.isSuccessful()) {
                toast("Current password is wrong.");
                return;
            }
            u.updatePassword(newPw).addOnCompleteListener(t2 -> {
                if (t2.isSuccessful()) {
                    etOldPw.setText("");
                    etNewPw.setText("");
                    toast("Password changed.");
                } else {
                    toast("Couldn't change it: " + (t2.getException() == null ? "" : t2.getException().getMessage()));
                }
            });
        });
    }

    private void signOut() {
        UserStore.get().stop();
        ProfileCache.clear();
        FirebaseAuth.getInstance().signOut();
        com.google.android.gms.auth.api.signin.GoogleSignIn.getClient(requireContext(),
                com.google.android.gms.auth.api.signin.GoogleSignInOptions.DEFAULT_SIGN_IN).signOut();
        Intent i = new Intent(requireContext(), AuthActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }

    // ---------------- delete account ----------------

    private void showDeleteDialog() {
        final FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) return;
        if (!hasPasswordProvider(u)) {
            toast("Google-signed accounts can be deleted from the VeusBid web app (Settings \u2192 Danger zone).");
            return;
        }
        View v = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_delete_account, null, false);
        final TextInputEditText word = v.findViewById(R.id.et_confirm_word);
        final TextInputEditText pw = v.findViewById(R.id.et_confirm_pw);
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete account")
                .setView(v)
                .setPositiveButton("Delete forever", (d, w) -> {
                    String typed = word.getText() == null ? "" : word.getText().toString().trim();
                    String pass = pw.getText() == null ? "" : pw.getText().toString();
                    if (!"DELETE".equals(typed)) {
                        toast("Type DELETE exactly to confirm.");
                        return;
                    }
                    if (pass.isEmpty()) {
                        toast("Enter your password.");
                        return;
                    }
                    deleteAccount(u, pass);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteAccount(final FirebaseUser u, String password) {
        final String uid = u.getUid();
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        u.reauthenticate(EmailAuthProvider.getCredential(u.getEmail(), password)).addOnCompleteListener(t -> {
            if (!t.isSuccessful()) {
                toast("Wrong password - nothing was deleted.");
                return;
            }
            // 1) your listings  2) your profile  3) the sign-in itself (order matters: rules need auth).
            db.collection("items").whereEqualTo("ownerUid", uid).get().addOnCompleteListener(q -> {
                if (!q.isSuccessful()) {
                    toast("Couldn't reach the server - nothing was deleted.");
                    return;
                }
                QuerySnapshot snap = q.getResult();
                WriteBatch batch = db.batch();
                int count = 0;
                if (snap != null) {
                    for (DocumentSnapshot d : snap.getDocuments()) {
                        if (count >= 450) break;
                        batch.delete(d.getReference());
                        count++;
                    }
                }
                batch.delete(db.collection("users").document(uid));
                batch.commit().addOnCompleteListener(b -> {
                    if (!b.isSuccessful()) {
                        toast("Couldn't delete your data - nothing else was removed.");
                        return;
                    }
                    u.delete().addOnCompleteListener(del -> {
                        UserStore.get().stop();
                        ProfileCache.clear();
                        if (!del.isSuccessful()) {
                            FirebaseAuth.getInstance().signOut();
                            toast("Your data was removed, but the sign-in couldn't be deleted. Sign in again and retry.");
                        } else {
                            toast("Account deleted.");
                        }
                        Intent i = new Intent(requireContext(), AuthActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                    });
                });
            });
        });
    }

    // ---------------- appearance ----------------

    private void restyle() {
        if (getActivity() != null) getActivity().recreate();
    }

    private TextView chip(String label, boolean selected, Typeface tf, View.OnClickListener l) {
        Context c = requireContext();
        TextView tv = new TextView(c);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setGravity(Gravity.CENTER);
        tv.setTextColor(Ui.color(c, selected ? R.attr.vbAccent : R.attr.vbText));
        tv.setBackgroundResource(selected ? R.drawable.bg_chip_selected : R.drawable.bg_chip);
        tv.setPadding(Ui.dp(c, 14), Ui.dp(c, 9), Ui.dp(c, 14), Ui.dp(c, 9));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMarginEnd(Ui.dp(c, 8));
        tv.setLayoutParams(lp);
        if (tf != null) {
            tv.setTypeface(tf);
            tv.setTag(R.id.tag_font_applied, Boolean.TRUE);   // keep the preview font, don't restyle
        }
        tv.setOnClickListener(l);
        return tv;
    }

    private GradientDrawable box(int fill, int stroke, int strokeDp, float radiusDp, boolean oval) {
        Context c = requireContext();
        GradientDrawable g = new GradientDrawable();
        g.setShape(oval ? GradientDrawable.OVAL : GradientDrawable.RECTANGLE);
        g.setColor(fill);
        g.setCornerRadius(Ui.dp(c, radiusDp));
        g.setStroke(Ui.dp(c, strokeDp), stroke);
        return g;
    }

    private void buildAppearance(View root) {
        final Context c = requireContext();
        LinearLayout modes = root.findViewById(R.id.row_mode);
        LinearLayout palettes = root.findViewById(R.id.row_palettes);
        LinearLayout accents = root.findViewById(R.id.row_accents);
        LinearLayout fonts = root.findViewById(R.id.row_fonts);
        LinearLayout sizes = root.findViewById(R.id.row_sizes);
        LinearLayout radius = root.findViewById(R.id.row_radius);
        CheckBox stars = root.findViewById(R.id.cb_starfield);

        // Mode: System follows the phone's day/night setting; the choice is remembered.
        String curM = Appearance.mode(c);
        String[][] modeOpts = {{Appearance.MODE_SYSTEM, "Match system"}, {Appearance.MODE_LIGHT, "Light"}, {Appearance.MODE_DARK, "Dark"}};
        for (final String[] mo : modeOpts) {
            modes.addView(chip(mo[1], mo[0].equals(curM), null, v -> {
                Appearance.setMode(c, mo[0]);
                restyle();
            }));
        }

        // Palette tiles: each tile previews its own background, text and two signature colours.
        final boolean light = Appearance.isLight(c);
        String curP = Appearance.paletteId(c);
        for (final Appearance.Palette p : Appearance.PALETTES) {
            boolean sel = p.id.equals(curP);
            LinearLayout tile = new LinearLayout(c);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setBackground(box(p.bg(light), sel ? p.accent(light) : 0x44888888, sel ? 3 : 1, 10, false));
            tile.setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10));
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(Ui.dp(c, 96), ViewGroup.LayoutParams.WRAP_CONTENT);
            tlp.setMarginEnd(Ui.dp(c, 8));
            tile.setLayoutParams(tlp);

            LinearLayout dots = new LinearLayout(c);
            dots.setGravity(Gravity.CENTER);
            for (int col : new int[]{p.accent(light), p.second(light), p.text(light)}) {
                View d = new View(c);
                LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(Ui.dp(c, 14), Ui.dp(c, 14));
                dlp.setMargins(Ui.dp(c, 2), 0, Ui.dp(c, 2), 0);
                d.setLayoutParams(dlp);
                d.setBackground(box(col, 0x33000000, 1, 7, true));
                dots.addView(d);
            }
            tile.addView(dots);
            TextView name = new TextView(c);
            name.setText(p.label);
            name.setTextSize(12);
            name.setTextColor(p.text(light));
            name.setTag(R.id.tag_font_applied, Boolean.TRUE);
            name.setPadding(0, Ui.dp(c, 6), 0, 0);
            tile.addView(name);
            tile.setOnClickListener(v -> {
                Appearance.setPalette(c, p.id);
                restyle();
            });
            palettes.addView(tile);
        }

        // Accent swatches (first = follow the palette).
        String curA = Appearance.accentId(c);
        accents.addView(chip("Auto", curA.isEmpty(), null, v -> {
            Appearance.setAccent(c, "");
            restyle();
        }));
        for (final Appearance.Accent a : Appearance.ACCENTS) {
            boolean sel = a.id.equals(curA);
            View sw = new View(c);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(Ui.dp(c, 40), Ui.dp(c, 40));
            slp.setMarginEnd(Ui.dp(c, 10));
            sw.setLayoutParams(slp);
            sw.setBackground(box(a.color(light), sel ? Ui.color(c, R.attr.vbText) : 0x33888888, sel ? 3 : 1, 20, true));
            sw.setContentDescription(a.label);
            sw.setOnClickListener(v -> {
                Appearance.setAccent(c, a.id);
                restyle();
            });
            accents.addView(sw);
        }

        // Fonts: every chip is drawn in its own typeface, so the row is its own preview.
        String curF = Appearance.fontId(c);
        for (final Appearance.Font f : Appearance.FONTS) {
            fonts.addView(chip(f.label, f.id.equals(curF), Typeface.create(f.family, Typeface.NORMAL), v -> {
                Appearance.setFont(c, f.id);
                restyle();
            }));
        }

        int curS = Appearance.sizeIndex(c);
        for (int i = 0; i < Appearance.SIZE_LABELS.length; i++) {
            final int idx = i;
            sizes.addView(chip(Appearance.SIZE_LABELS[i], i == curS, null, v -> {
                Appearance.setSize(c, idx);
                restyle();
            }));
        }

        int curR = Appearance.radiusIndex(c);
        for (int i = 0; i < Appearance.RADIUS_LABELS.length; i++) {
            final int idx = i;
            radius.addView(chip(Appearance.RADIUS_LABELS[i], i == curR, null, v -> {
                Appearance.setRadius(c, idx);
                restyle();
            }));
        }

        stars.setChecked(Appearance.starfield(c));
        stars.setOnCheckedChangeListener((b, on) -> {
            Appearance.setStarfield(c, on);
            if (getActivity() != null) {
                View sf = getActivity().findViewById(R.id.starfield);
                if (sf != null) sf.setVisibility(on ? View.VISIBLE : View.GONE);
            }
        });

        root.findViewById(R.id.btn_reset_look).setOnClickListener(v -> {
            Appearance.reset(c);
            restyle();
        });
    }

    private void toast(String m) {
        if (isAdded()) Toast.makeText(requireContext(), m, Toast.LENGTH_LONG).show();
    }
}
