package com.veus.veusbid.util;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;

import com.veus.veusbid.R;

/** User-chosen look & feel: palette, accent override, corner radius, font, text size, starfield. */
public final class Appearance {

    public static final class Palette {
        public final String id;
        public final String label;
        public final int styleDark;
        public final int styleLight;
        private final int[] dark;    // bg, text, accent, second (for the preview tile)
        private final int[] light;

        Palette(String id, String label, int styleDark, int styleLight, int[] dark, int[] light) {
            this.id = id; this.label = label; this.styleDark = styleDark; this.styleLight = styleLight;
            this.dark = dark; this.light = light;
        }

        public int bg(boolean l) { return (l ? light : dark)[0]; }
        public int text(boolean l) { return (l ? light : dark)[1]; }
        public int accent(boolean l) { return (l ? light : dark)[2]; }
        public int second(boolean l) { return (l ? light : dark)[3]; }
    }

    public static final class Accent {
        public final String id;
        public final String label;
        public final int styleDark;
        public final int styleLight;
        private final int colorDark;
        private final int colorLight;

        Accent(String id, String label, int styleDark, int styleLight, int colorDark, int colorLight) {
            this.id = id; this.label = label; this.styleDark = styleDark; this.styleLight = styleLight;
            this.colorDark = colorDark; this.colorLight = colorLight;
        }

        public int color(boolean l) { return l ? colorLight : colorDark; }
    }

    public static final class Font {
        public final String id;
        public final String label;
        public final String family;

        Font(String id, String label, String family) {
            this.id = id; this.label = label; this.family = family;
        }
    }

    public static final Palette[] PALETTES = {
            new Palette("plasma", "Plasma", R.style.Palette_Plasma, R.style.PaletteLight_Plasma,
                    new int[]{0xFF03010A, 0xFFC8FFE8, 0xFF00FFD4, 0xFF7B2FFF}, new int[]{0xFFF4F7F8, 0xFF0B1F1B, 0xFF00806B, 0xFF6B2BE0}),
            new Palette("ember", "Ember", R.style.Palette_Ember, R.style.PaletteLight_Ember,
                    new int[]{0xFF0C0503, 0xFFFFE8D6, 0xFFFF7A1A, 0xFFFF2E63}, new int[]{0xFFFBF5F0, 0xFF2A140A, 0xFFD85A00, 0xFFD81B50}),
            new Palette("aurora", "Aurora", R.style.Palette_Aurora, R.style.PaletteLight_Aurora,
                    new int[]{0xFF02080A, 0xFFD9FFF2, 0xFF5CFF9D, 0xFF3DA5FF}, new int[]{0xFFF2F9F5, 0xFF0A2418, 0xFF12874A, 0xFF1F6FD1}),
            new Palette("sakura", "Sakura", R.style.Palette_Sakura, R.style.PaletteLight_Sakura,
                    new int[]{0xFF0D0510, 0xFFFFE6F4, 0xFFFF8AD8, 0xFFB26BFF}, new int[]{0xFFFBF3F8, 0xFF2B1024, 0xFFC2278F, 0xFF7B3FD6}),
            new Palette("gilded", "Gilded", R.style.Palette_Gilded, R.style.PaletteLight_Gilded,
                    new int[]{0xFF0A0805, 0xFFFFF3D6, 0xFFFFC93C, 0xFFFF8A3C}, new int[]{0xFFFBF7EC, 0xFF2A200A, 0xFFA87400, 0xFFC2570F}),
            new Palette("glacier", "Glacier", R.style.Palette_Glacier, R.style.PaletteLight_Glacier,
                    new int[]{0xFF040A12, 0xFFE3F3FF, 0xFF7FD4FF, 0xFF8C9BFF}, new int[]{0xFFF1F7FC, 0xFF0C2236, 0xFF0B6FB5, 0xFF4B5BD6}),
            new Palette("mono", "Mono", R.style.Palette_Mono, R.style.PaletteLight_Mono,
                    new int[]{0xFF000000, 0xFFF2F2F2, 0xFFFFFFFF, 0xFF8A8A8A}, new int[]{0xFFFFFFFF, 0xFF111111, 0xFF111111, 0xFF666666}),
    };

    public static final Accent[] ACCENTS = {
            new Accent("cyan", "Cyan", R.style.Accent_Cyan, R.style.AccentLight_Cyan, 0xFF00FFD4, 0xFF00806B),
            new Accent("lime", "Lime", R.style.Accent_Lime, R.style.AccentLight_Lime, 0xFFB6FF3B, 0xFF4F8A00),
            new Accent("amber", "Amber", R.style.Accent_Amber, R.style.AccentLight_Amber, 0xFFFFC24B, 0xFFA87400),
            new Accent("coral", "Coral", R.style.Accent_Coral, R.style.AccentLight_Coral, 0xFFFF6B6B, 0xFFD23F3F),
            new Accent("rose", "Rose", R.style.Accent_Rose, R.style.AccentLight_Rose, 0xFFFF5DA2, 0xFFC2276F),
            new Accent("violet", "Violet", R.style.Accent_Violet, R.style.AccentLight_Violet, 0xFFA66BFF, 0xFF6B2BE0),
            new Accent("sky", "Sky", R.style.Accent_Sky, R.style.AccentLight_Sky, 0xFF4DB8FF, 0xFF0B6FB5),
            new Accent("mint", "Mint", R.style.Accent_Mint, R.style.AccentLight_Mint, 0xFF6BFFB8, 0xFF12874A),
    };

    /** System font families only - no font files to bundle, nothing to download, always available. */
    public static final Font[] FONTS = {
            new Font("default", "Standard", "sans-serif"),
            new Font("tech", "Techno", "monospace"),
            new Font("elegant", "Elegant", "serif"),
            new Font("compact", "Compact", "sans-serif-condensed"),
            new Font("slim", "Slim", "sans-serif-light"),
            new Font("script", "Script", "cursive"),
            new Font("playful", "Playful", "casual"),
            new Font("typewriter", "Typewriter", "serif-monospace"),
    };

    public static final String[] SIZE_LABELS = {"Compact", "Normal", "Large", "Huge"};
    public static final float[] SIZE_SCALES = {0.9f, 1.0f, 1.15f, 1.3f};
    public static final String[] RADIUS_LABELS = {"Sharp", "Soft", "Round"};
    private static final int[] RADIUS_STYLES = {R.style.Radius_Sharp, R.style.Radius_Soft, R.style.Radius_Round};

    private static final String PREFS = "vb_appearance";
    private static final String K_PALETTE = "palette";
    private static final String K_ACCENT = "accent";
    private static final String K_FONT = "font";
    private static final String K_SIZE = "size";
    private static final String K_RADIUS = "radius";
    private static final String K_STARS = "stars";
    private static final String K_MODE = "mode";

    public static final String MODE_SYSTEM = "system";
    public static final String MODE_LIGHT = "light";
    public static final String MODE_DARK = "dark";

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String paletteId(Context c) { return p(c).getString(K_PALETTE, "plasma"); }
    /** "" means "use the palette's own accent". */
    public static String accentId(Context c) { return p(c).getString(K_ACCENT, ""); }
    public static String fontId(Context c) { return p(c).getString(K_FONT, "default"); }
    public static int sizeIndex(Context c) { return Math.max(0, Math.min(p(c).getInt(K_SIZE, 1), SIZE_SCALES.length - 1)); }
    public static int radiusIndex(Context c) { return Math.max(0, Math.min(p(c).getInt(K_RADIUS, 1), 2)); }
    public static boolean starfield(Context c) { return p(c).getBoolean(K_STARS, true); }

    /** Default is dark (the VeusBid look); "system" follows the phone's day/night setting. */
    public static String mode(Context c) { return p(c).getString(K_MODE, MODE_DARK); }
    public static void setMode(Context c, String m) { p(c).edit().putString(K_MODE, m).apply(); }

    /** Resolved mode for this context: true = light. */
    public static boolean isLight(Context c) {
        String m = mode(c);
        if (MODE_LIGHT.equals(m)) return true;
        if (MODE_SYSTEM.equals(m)) {
            int night = c.getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
            return night != android.content.res.Configuration.UI_MODE_NIGHT_YES;
        }
        return false;
    }

    public static void setPalette(Context c, String id) { p(c).edit().putString(K_PALETTE, id).apply(); }
    public static void setAccent(Context c, String id) { p(c).edit().putString(K_ACCENT, id).apply(); }
    public static void setFont(Context c, String id) { p(c).edit().putString(K_FONT, id).apply(); }
    public static void setSize(Context c, int i) { p(c).edit().putInt(K_SIZE, i).apply(); }
    public static void setRadius(Context c, int i) { p(c).edit().putInt(K_RADIUS, i).apply(); }
    public static void setStarfield(Context c, boolean on) { p(c).edit().putBoolean(K_STARS, on).apply(); }
    public static void reset(Context c) { p(c).edit().clear().apply(); }

    public static float scale(Context c) { return SIZE_SCALES[sizeIndex(c)]; }

    public static Font font(Context c) {
        String id = fontId(c);
        for (Font f : FONTS) if (f.id.equals(id)) return f;
        return FONTS[0];
    }

    public static Typeface typeface(Context c, int style) {
        return Typeface.create(font(c).family, style);
    }

    /** True when fonts/sizes are untouched, so FontStyler can skip all work. */
    public static boolean isDefaultTypography(Context c) {
        return "default".equals(fontId(c)) && sizeIndex(c) == 1;
    }

    /**
     * Must run before super.onCreate / setContentView. Picks the dark or light Material base theme, then
     * layers palette -> accent -> radius overlays on top of it.
     */
    public static void applyTheme(Activity a) {
        boolean light = isLight(a);
        a.setTheme(light ? R.style.Theme_VeusBid_Light : R.style.Theme_VeusBid);
        String pid = paletteId(a);
        for (Palette pal : PALETTES) {
            if (pal.id.equals(pid)) {
                a.getTheme().applyStyle(light ? pal.styleLight : pal.styleDark, true);
                break;
            }
        }
        String aid = accentId(a);
        if (!aid.isEmpty()) {
            for (Accent ac : ACCENTS) {
                if (ac.id.equals(aid)) {
                    a.getTheme().applyStyle(light ? ac.styleLight : ac.styleDark, true);
                    break;
                }
            }
        }
        a.getTheme().applyStyle(RADIUS_STYLES[radiusIndex(a)], true);
    }

    private Appearance() { }
}
