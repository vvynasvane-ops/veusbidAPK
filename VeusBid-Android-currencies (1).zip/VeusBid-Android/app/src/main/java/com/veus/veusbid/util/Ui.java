package com.veus.veusbid.util;

import android.content.Context;
import android.util.TypedValue;

public final class Ui {
    /** Resolves a theme colour attribute (e.g. R.attr.vbAccent) against the context's current theme. */
    public static int color(Context c, int attr) {
        TypedValue tv = new TypedValue();
        c.getTheme().resolveAttribute(attr, tv, true);
        return tv.data;
    }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    private Ui() { }
}
