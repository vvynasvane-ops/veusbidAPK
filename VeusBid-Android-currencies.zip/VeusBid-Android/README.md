# VeusBid — native Android (Java + XML)

Native port of the VeusBid web app (live auctions) on the **same Firebase project and Firestore schema**,
so Android and web users share listings, bids, chats and profiles.

- Java 17 source level, XML layouts, Material 3 dark theme (plasma-cyan `#00FFD4` / ultraviolet `#7B2FFF` on void black)
- minSdk 24 · compileSdk/targetSdk 34 · AGP 8.7.3 · Gradle 8.10.2 · Firebase BoM 33.5.1 (Auth + Firestore only)
- No Firebase Storage / billing needed: photos are compressed JPEG data-URLs inside the item document, like the web app

## 1. One-time setup
1. `setup_wrapper.bat` (downloads `gradle-wrapper.jar` if missing, writes `local.properties` with your SDK path).
   The jar is already bundled, so normally nothing happens.
2. SDK: install **Android SDK Platform 34** + Build-Tools 34.x (SDK Manager).
3. **Firebase (recommended):** Firebase console → project `veusbid` → add an **Android app** with package
   `com.veus.veusbid` → add your debug SHA-1 → download `google-services.json` into `app/`.
   The build detects it automatically. Without it the app still builds and falls back to the web config in
   `FirebaseConfig.java` (works for Email/Password + Firestore, but if your web API key is restricted to
   websites you'll get "API key not valid" — then do the step above).
4. Firebase console → Authentication: Email/Password enabled.
5. **Publish the bundled `firestore.rules`** (see "Rules fix" below) and deploy `firestore.indexes.json`
   (`firebase deploy --only firestore:indexes`) so the Messages inbox works.

## 2. Build (Windows)
```
clean_build.bat          :: clean + assembleDebug (also runs setup_wrapper.bat)
build_debug.bat          :: incremental debug build
gradlew.bat clean
gradlew.bat assembleDebug
```
APK: `app\build\outputs\apk\debug\app-debug.apk`

If JDK 23 gives toolchain / `jlink` / `JdkImageTransform` errors, install JDK 17 or 21 and uncomment
`org.gradle.java.home` in `gradle.properties`.

## 3. What's implemented (parity map)
| Area | Android |
|---|---|
| Auth | Email/password sign-up (confirm password), log in, forgot-password email, auto profile-doc repair |
| Browse | Live Firestore listener, search (title/category/description/code), sort (5 modes), filters (category, price range, condition, ending ≤1h, has photo, watchlist only, include ended), ticking countdowns, blocked sellers hidden, watch heart |
| Item page | Photo pager, live price/bid count/countdown, min-increment table, **transactional** bid + bid-history write, 2-minute anti-snipe, bid history (live), feedback chips + list, share, calendar reminder, report, block, message seller, seller contact |
| Sell | Create (title, category, condition, start price, reserve, length in min/hours/days, location, description, contact, ≤6 photos), edit until first bid, delete, **End now**, mark delivered, winner shown |
| After sale | Seller "Message winner" with delivery template; winner "Share my delivery details" |
| Messages | Inbox (unread dot, search, deleted-account handling), chat with seen tick, send-failure restore, shared thread ids with web |
| Account | Name/phone/photo, online-status toggle, change password (re-auth), blocked list, sign out, delete account (items → profile → auth) |
| Google sign-in | "Continue with Google" on the login screen (classic `GoogleSignInClient` + Firebase credential). Same Firebase users as the web app; account chooser always shown; signs out of Google on logout |
| Appearance | Account → Appearance: **Mode: Match system / Light / Dark**, 7 palettes (each with a tuned light and dark version), 8 accent colours, 8 font styles, 4 text sizes, 3 corner styles, animated starfield, live preview card, reset |
| Alerts | In-app + system notification when you're outbid (while the app is open) |

Not ported (kept out to stay stable): typing indicator,
chat PIN lock, theme/RGB customiser, recommendations/saved presets, background push (needs FCM + backend).

## 4. Rules fix (important)
The original rule for a bid required `currentBid > startingPrice` even on the **first** bid, but both UIs allow a
first bid equal to the starting price, so that bid was rejected with PERMISSION_DENIED. The bundled
`firestore.rules` accepts `>= startingPrice` for the first bid and `> currentBid` afterwards; everything else is unchanged.
Bids are written in one Firestore transaction (price check + item update + bid record), closing the web app's
documented race condition.

## 5. Layout
```
app/src/main/java/com/veus/veusbid/
  VeusBidApp, FirebaseConfig
  data/  Item, ChatThread, Message, UserStore, ProfileCache, OutbidWatcher
  util/  Const, Fmt, ImageUtil, Notifier
  ui/    AuthActivity, MainActivity, BrowseFragment(+AuctionAdapter), ListingsFragment(+MyListingAdapter),
         EditListingActivity, ItemActivity, MessagesFragment, ChatActivity, SettingsFragment
```

## 6. Google sign-in setup (required once)
1. Firebase console → Authentication → Sign-in method → **Google → Enable** (set a support email).
2. Get your debug SHA-1: `gradlew.bat signingReport` (look for `Variant: debug` → SHA1), or
   `keytool -list -v -keystore %USERPROFILE%\.android\debug.keystore -alias androiddebugkey -storepass android`.
3. Project settings → your Android app (`com.veus.veusbid`) → **Add fingerprint** → paste the SHA-1
   (add the release SHA-1 later too).
4. Download a fresh `google-services.json` into `app/` (it now contains the Web client the build uses).
   Alternative without the file: paste the Web client ID into `FirebaseConfig.WEB_CLIENT_ID`.
5. Rebuild. Error code 10 on the button = SHA-1 / package mismatch; fix step 3.

Accounts that signed in with Google can change their password and delete their account from the web app
(those two actions need a password re-auth that Google accounts don't have in-app).

## 7. Appearance system (how it works)
Every colour in layouts/drawables is a theme attribute (`?attr/vbAccent`, `vbBg`, ...). A choice in
Account → Appearance is saved in SharedPreferences and layered onto the theme before each screen is created:
`Palette.* → Accent.* → Radius.*` (see `values/themes.xml`, `util/Appearance.java`). Fonts use Android's built-in
families (no downloads); `FontStyler` applies family + text-size scale to each screen. Add your own palette by
copying one `Palette.*` style and adding a row to `Appearance.PALETTES`.

### Light / dark mode
Account → Appearance → **Mode**. Default is Dark; *Match system* follows the phone's day/night setting live.
Light mode uses the Material 3 *light* base theme (`Theme.VeusBid.Light`) plus a `PaletteLight.*` overlay and a darker
`AccentLight.*` set, so text keeps proper contrast; status/navigation bar icons flip automatically.

## 8. Fix log
- **Launch crash on MainActivity** (`InflateException ... BottomNavigationView`, `Resources$NotFoundException: Resource ID #0x0`):
  Material's nav bar resolves `android:textColorSecondary` and needs a real colour *resource*, but the themes pointed it
  (and textColorPrimary/Hint) straight at `?attr/vb*` literals. They now point to selector resources
  (`res/color/vb_text_primary.xml`, `vb_text_secondary.xml`) that read the palette attributes, so palettes/accents/light-dark
  still work. The bottom nav also gets explicit `vb_nav_item` icon/label colours (accent when selected, muted otherwise).

### Google sign-in diagnostics (new)
- Web client ID is now auto-discovered from the Firebase project when `google-services.json` / `WEB_CLIENT_ID` are missing.
- A closed/rejected chooser is no longer swallowed silently; the real status code is shown and logged (tag `VeusBidAuth`).
- On any native failure other than "cancelled"/"network", the app falls back to Firebase's browser-based Google flow.
- If that also fails, the error shows this build's SHA-1 (copied to the clipboard) to paste under
  Firebase console -> Project settings -> Android app -> Add fingerprint.

## 9. Multi-currency listings
- Sellers pick a currency per listing (32 built in: KES, UGX, TZS, RWF, ETB, NGN, GHS, ZAR, EGP, USD, EUR, GBP, JPY, INR, AED... see `util/Currency.java`). Stored as `currency` on the item; listings without it read as USD, so old data and the web app keep working.
- Everything on a listing (bids, reserve, outbid alerts, share text, bid history) uses that listing's currency.
- Bid steps scale with the currency (e.g. KSh 500 / 1,000 / 2,500 instead of $5 / $10 / $25). USD is unchanged.
- The listing form defaults to the last currency used, then the phone's locale currency.
- The item page shows a flag and an approximate "about" price in the viewer's currency. Browse has a currency filter, and sorting by price compares across currencies.
- Reference rates in `Currency.java` (`perUsd`) are rough and only used for display, sorting and filtering. They never decide a bid. Edit them whenever you like.
- No Firestore rules change is needed.
