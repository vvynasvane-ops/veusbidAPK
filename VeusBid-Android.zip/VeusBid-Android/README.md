# VeusBid — native Android (Java + XML)

Native port of the VeusBid web app (live auctions) on the **same Firebase project and Firestore schema**,
so Android and web users share listings, bids, chats and profiles.

- Java 17 source level, XML layouts, Material 3 dark theme (plasma-cyan `#00FFD4` / ultraviolet `#7B2FFF` on void black)
- minSdk 24 · compileSdk/targetSdk 34 · AGP 8.7.3 · Gradle 8.10.2 · Firebase BoM 33.5.1 (Auth + Firestore only)
- No Firebase Storage / billing needed: photos are compressed JPEG data-URLs inside the item document, like the web app

## 1. One-time setup
1. `setup_wrapper.bat` (downloads `gradle-wrapper.jar` if missing, writes `local.properties` with your SDK path).
   The jar is already bundled, so normally nothing happens.
2. SDK: install **Android SDK Platform 34** + Build-Tools 34.x (SDK Manager).
3. **Firebase (recommended):** Firebase console → project `veusbid` → add an **Android app** with package
   `com.veus.veusbid` → add your debug SHA-1 → download `google-services.json` into `app/`.
   The build detects it automatically. Without it the app still builds and falls back to the web config in
   `FirebaseConfig.java` (works for Email/Password + Firestore, but if your web API key is restricted to
   websites you'll get "API key not valid" — then do the step above).
4. Firebase console → Authentication: Email/Password enabled.
5. **Publish the bundled `firestore.rules`** (see "Rules fix" below) and deploy `firestore.indexes.json`
   (`firebase deploy --only firestore:indexes`) so the Messages inbox works.

## 2. Build (Windows)
```
clean_build.bat          :: clean + assembleDebug (also runs setup_wrapper.bat)
build_debug.bat          :: incremental debug build
gradlew.bat clean
gradlew.bat assembleDebug
```
APK: `app\build\outputs\apk\debug\app-debug.apk`

If JDK 23 gives toolchain / `jlink` / `JdkImageTransform` errors, install JDK 17 or 21 and uncomment
`org.gradle.java.home` in `gradle.properties`.

## 3. What's implemented (parity map)
| Area | Android |
|---|---|
| Auth | Email/password sign-up (confirm password), log in, forgot-password email, auto profile-doc repair |
| Browse | Live Firestore listener, search (title/category/description/code), sort (5 modes), filters (category, price range, condition, ending ≤1h, has photo, watchlist only, include ended), ticking countdowns, blocked sellers hidden, watch heart |
| Item page | Photo pager, live price/bid count/countdown, min-increment table, **transactional** bid + bid-history write, 2-minute anti-snipe, bid history (live), feedback chips + list, share, calendar reminder, report, block, message seller, seller contact |
| Sell | Create (title, category, condition, start price, reserve, length in min/hours/days, location, description, contact, ≤6 photos), edit until first bid, delete, **End now**, mark delivered, winner shown |
| After sale | Seller "Message winner" with delivery template; winner "Share my delivery details" |
| Messages | Inbox (unread dot, search, deleted-account handling), chat with seen tick, send-failure restore, shared thread ids with web |
| Account | Name/phone/photo, online-status toggle, change password (re-auth), blocked list, sign out, delete account (items → profile → auth) |
| Alerts | In-app + system notification when you're outbid (while the app is open) |

Not ported (kept out to stay stable): Google sign-in (needs SHA-1 + Credential Manager), typing indicator,
chat PIN lock, theme/RGB customiser, recommendations/saved presets, background push (needs FCM + backend).

## 4. Rules fix (important)
The original rule for a bid required `currentBid > startingPrice` even on the **first** bid, but both UIs allow a
first bid equal to the starting price, so that bid was rejected with PERMISSION_DENIED. The bundled
`firestore.rules` accepts `>= startingPrice` for the first bid and `> currentBid` afterwards; everything else is unchanged.
Bids are written in one Firestore transaction (price check + item update + bid record), closing the web app's
documented race condition.

## 5. Layout
```
app/src/main/java/com/veus/veusbid/
  VeusBidApp, FirebaseConfig
  data/  Item, ChatThread, Message, UserStore, ProfileCache, OutbidWatcher
  util/  Const, Fmt, ImageUtil, Notifier
  ui/    AuthActivity, MainActivity, BrowseFragment(+AuctionAdapter), ListingsFragment(+MyListingAdapter),
         EditListingActivity, ItemActivity, MessagesFragment, ChatActivity, SettingsFragment
```
