package com.veus.veusbid;

/**
 * Fallback Firebase options, copied from the web app's firebase-config.js.
 * Used ONLY when app/google-services.json is absent (see VeusBidApp).
 *
 * Recommended for production: register an Android app (package com.veus.veusbid) in the
 * Firebase console and drop its google-services.json into /app - then this file is ignored.
 */
public final class FirebaseConfig {
    public static final String API_KEY = "AIzaSyD48AHi-3L6S96sIsJu-h7xJ61PVO5-6zs";
    public static final String APP_ID = "1:420976430868:web:9224f3431ffe77523a7c01";
    public static final String PROJECT_ID = "veusbid";
    public static final String STORAGE_BUCKET = "veusbid.firebasestorage.app";
    public static final String SENDER_ID = "420976430868";

    private FirebaseConfig() { }
}
