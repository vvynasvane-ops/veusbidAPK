package com.veus.veusbid.data;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QuerySnapshot;
import com.veus.veusbid.ui.ItemActivity;
import com.veus.veusbid.util.Const;
import com.veus.veusbid.util.Fmt;
import com.veus.veusbid.util.Notifier;

import java.util.HashMap;
import java.util.Map;

/**
 * While the app is open, watches every auction you've bid on and alerts you the moment someone
 * tops you (toast + system notification when permitted). Not background push - that needs FCM.
 */
public final class OutbidWatcher {

    private final Context appContext;
    private final String myUid;
    private ListenerRegistration reg;
    private final Map<String, String> lastBidder = new HashMap<>();

    public OutbidWatcher(Context context, String myUid) {
        this.appContext = context.getApplicationContext();
        this.myUid = myUid;
    }

    public void start() {
        if (reg != null) return;
        reg = FirebaseFirestore.getInstance().collection("items")
                .whereArrayContains("everBidUids", myUid)
                .addSnapshotListener((QuerySnapshot snap, FirebaseFirestoreException e) -> {
                    if (snap == null) return;
                    for (DocumentChange dc : snap.getDocumentChanges()) {
                        Item it = Item.from(dc.getDocument());
                        if (dc.getType() == DocumentChange.Type.REMOVED) {
                            lastBidder.remove(it.id);
                            continue;
                        }
                        String prev = lastBidder.get(it.id);
                        boolean wasMine = prev != null && prev.equals(myUid);
                        boolean notMineNow = it.currentBidderUid != null && !it.currentBidderUid.equals(myUid);
                        if (dc.getType() == DocumentChange.Type.MODIFIED && wasMine && notMineNow) {
                            alert(it);
                        }
                        lastBidder.put(it.id, it.currentBidderUid == null ? "" : it.currentBidderUid);
                    }
                });
    }

    public void stop() {
        if (reg != null) reg.remove();
        reg = null;
        lastBidder.clear();
    }

    private void alert(Item it) {
        String msg = "You were outbid on \"" + it.title + "\" - now " + Fmt.money(it.current());
        Toast.makeText(appContext, msg, Toast.LENGTH_LONG).show();
        Intent tap = new Intent(appContext, ItemActivity.class);
        tap.putExtra(Const.EXTRA_ITEM_ID, it.id);
        tap.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Notifier.post(appContext, it.id.hashCode(), "Outbid!", msg, tap);
    }
}
