package com.veus.veusbid.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.veus.veusbid.R;
import com.veus.veusbid.data.OutbidWatcher;
import com.veus.veusbid.data.UserStore;

/** Hosts the four tabs. Fragments are added once and shown/hidden so scroll/search state survives. */
public class MainActivity extends AppCompatActivity {

    private static final String TAG_BROWSE = "browse";
    private static final String TAG_SELL = "sell";
    private static final String TAG_MESSAGES = "messages";
    private static final String TAG_ACCOUNT = "account";
    private static final String[] TAGS = {TAG_BROWSE, TAG_SELL, TAG_MESSAGES, TAG_ACCOUNT};

    private OutbidWatcher watcher;

    private final ActivityResultLauncher<String> notifPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> { });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Intent i = new Intent(this, AuthActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
            return;
        }
        setContentView(R.layout.activity_main);
        UserStore.get().start(user.getUid());

        final FragmentManager fm = getSupportFragmentManager();
        if (savedInstanceState == null) {
            FragmentTransaction ft = fm.beginTransaction();
            ft.add(R.id.container, new BrowseFragment(), TAG_BROWSE);
            ft.add(R.id.container, new ListingsFragment(), TAG_SELL);
            ft.add(R.id.container, new MessagesFragment(), TAG_MESSAGES);
            ft.add(R.id.container, new SettingsFragment(), TAG_ACCOUNT);
            ft.commitNow();
            show(TAG_BROWSE);
        }

        BottomNavigationView nav = findViewById(R.id.bottom_nav);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_browse) show(TAG_BROWSE);
            else if (id == R.id.nav_sell) show(TAG_SELL);
            else if (id == R.id.nav_messages) show(TAG_MESSAGES);
            else if (id == R.id.nav_account) show(TAG_ACCOUNT);
            else return false;
            return true;
        });

        watcher = new OutbidWatcher(this, user.getUid());
        watcher.start();

        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }

    private void show(String tag) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        for (String t : TAGS) {
            Fragment f = fm.findFragmentByTag(t);
            if (f == null) continue;
            if (t.equals(tag)) ft.show(f); else ft.hide(f);
        }
        ft.commitNowAllowingStateLoss();
    }

    @Override
    protected void onResume() {
        super.onResume();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            // "Active recently" ping; fails harmlessly if the profile doc doesn't exist yet.
            FirebaseFirestore.getInstance().collection("users").document(user.getUid())
                    .update("lastActive", FieldValue.serverTimestamp());
        }
    }

    @Override
    protected void onDestroy() {
        if (watcher != null) watcher.stop();
        super.onDestroy();
    }
}
