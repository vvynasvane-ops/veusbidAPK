package com.veus.veusbid.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.veus.veusbid.R;
import com.veus.veusbid.data.ChatThread;
import com.veus.veusbid.data.ProfileCache;
import com.veus.veusbid.util.Const;
import com.veus.veusbid.util.Fmt;
import com.veus.veusbid.util.ImageUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Inbox: every conversation you're in, newest first, with an unread dot. */
public class MessagesFragment extends Fragment {

    private final List<ChatThread> all = new ArrayList<>();
    private final List<ChatThread> shown = new ArrayList<>();
    private String search = "";
    private String myUid;
    private ListenerRegistration reg;
    private ThreadAdapter adapter;
    private TextView tvEmpty;
    private boolean loaded = false;
    private String error = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        return inflater.inflate(R.layout.fragment_messages, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        super.onViewCreated(view, state);
        tvEmpty = view.findViewById(R.id.tv_inbox_empty);
        RecyclerView rv = view.findViewById(R.id.rv_threads);
        adapter = new ThreadAdapter();
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        rv.setAdapter(adapter);
        ((android.widget.EditText) view.findViewById(R.id.et_inbox_search)).addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override
            public void afterTextChanged(Editable s) {
                search = s.toString().trim().toLowerCase(Locale.getDefault());
                refilter();
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        myUid = FirebaseAuth.getInstance().getUid();
        if (myUid == null || reg != null) return;
        // Needs the composite index in firestore.indexes.json (participants + lastAt desc).
        reg = FirebaseFirestore.getInstance().collection("threads")
                .whereArrayContains("participants", myUid)
                .orderBy("lastAt", Query.Direction.DESCENDING)
                .addSnapshotListener((QuerySnapshot snap, FirebaseFirestoreException e) -> {
                    loaded = true;
                    if (e != null) {
                        error = e.getCode() == FirebaseFirestoreException.Code.FAILED_PRECONDITION
                                ? "Messages need a Firestore index. Deploy firestore.indexes.json "
                                + "(firebase deploy --only firestore:indexes) or open the link in Logcat to create it."
                                : "Couldn't load messages: " + e.getMessage();
                        refilter();
                        return;
                    }
                    if (snap == null) return;
                    error = null;
                    all.clear();
                    for (DocumentSnapshot d : snap.getDocuments()) all.add(ChatThread.from(d, myUid));
                    refilter();
                });
    }

    @Override
    public void onDestroyView() {
        if (reg != null) reg.remove();
        reg = null;
        super.onDestroyView();
    }

    private void refilter() {
        if (adapter == null) return;
        shown.clear();
        for (ChatThread t : all) {
            ProfileCache.Info info = ProfileCache.peek(t.otherUid);
            String name = info == null ? "" : info.name.toLowerCase(Locale.getDefault());
            if (search.isEmpty() || name.contains(search) || t.lastText.toLowerCase(Locale.getDefault()).contains(search)) {
                shown.add(t);
            }
        }
        adapter.notifyDataSetChanged();
        if (error != null) {
            tvEmpty.setText(error);
            tvEmpty.setVisibility(View.VISIBLE);
        } else if (!loaded) {
            tvEmpty.setText("Loading conversations...");
            tvEmpty.setVisibility(View.VISIBLE);
        } else if (shown.isEmpty()) {
            tvEmpty.setText(all.isEmpty() ? "No conversations yet. Open a listing and tap \"Message seller\"."
                    : "No conversations match your search.");
            tvEmpty.setVisibility(View.VISIBLE);
        } else {
            tvEmpty.setVisibility(View.GONE);
        }
    }

    private final class ThreadAdapter extends RecyclerView.Adapter<ThreadAdapter.VH> {
        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_thread, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull final VH h, int position) {
            final ChatThread t = shown.get(position);
            h.name.setText("...");
            h.initial.setText("?");
            h.avatar.setImageDrawable(null);
            h.preview.setText((t.lastFrom.equals(myUid) ? "You: " : "") + t.lastText);
            h.when.setText(Fmt.relative(t.lastAt));
            h.dot.setVisibility(t.isUnread(myUid) ? View.VISIBLE : View.INVISIBLE);
            h.itemView.setTag(t.otherUid);
            ProfileCache.get(t.otherUid, info -> {
                if (!t.otherUid.equals(h.itemView.getTag())) return;
                h.name.setText(info.name);
                h.initial.setText(Fmt.initial(info.name));
                ImageUtil.load(h.avatar, info.photo.isEmpty() ? null : info.photo, 120);
            });
            h.itemView.setOnClickListener(v -> {
                ProfileCache.Info info = ProfileCache.peek(t.otherUid);
                Intent i = new Intent(requireContext(), ChatActivity.class);
                i.putExtra(Const.EXTRA_OTHER_UID, t.otherUid);
                i.putExtra(Const.EXTRA_OTHER_NAME, info == null ? "" : info.name);
                startActivity(i);
            });
        }

        @Override
        public int getItemCount() {
            return shown.size();
        }

        final class VH extends RecyclerView.ViewHolder {
            final TextView initial;
            final ImageView avatar;
            final TextView name;
            final TextView preview;
            final TextView when;
            final View dot;

            VH(View v) {
                super(v);
                initial = v.findViewById(R.id.tv_initial);
                avatar = v.findViewById(R.id.iv_avatar);
                name = v.findViewById(R.id.tv_name);
                preview = v.findViewById(R.id.tv_preview);
                when = v.findViewById(R.id.tv_when);
                dot = v.findViewById(R.id.dot_unread);
            }
        }
    }
}
