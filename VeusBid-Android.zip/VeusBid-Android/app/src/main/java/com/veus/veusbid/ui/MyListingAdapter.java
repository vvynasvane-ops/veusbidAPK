package com.veus.veusbid.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.veus.veusbid.R;
import com.veus.veusbid.data.Item;
import com.veus.veusbid.util.Fmt;
import com.veus.veusbid.util.ImageUtil;

import java.util.ArrayList;
import java.util.List;

public class MyListingAdapter extends RecyclerView.Adapter<MyListingAdapter.VH> {

    public interface Callbacks {
        void onOpen(Item it);
        void onEdit(Item it);
        void onEnd(Item it);
        void onFulfill(Item it);
        void onDelete(Item it);
    }

    private static final Object TICK = new Object();

    private final List<Item> data = new ArrayList<>();
    private final Callbacks cb;

    public MyListingAdapter(Callbacks cb) {
        this.cb = cb;
    }

    public void submit(List<Item> items) {
        data.clear();
        data.addAll(items);
        notifyDataSetChanged();
    }

    public void tick() {
        if (!data.isEmpty()) notifyItemRangeChanged(0, data.size(), TICK);
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_listing, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position, @NonNull List<Object> payloads) {
        if (!payloads.isEmpty()) {
            bindStatus(h, data.get(position));
            return;
        }
        super.onBindViewHolder(h, position, payloads);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final Item it = data.get(position);
        h.title.setText(it.title.isEmpty() ? "Untitled item" : it.title);
        h.price.setText(Fmt.money(it.current()));
        h.meta.setText(it.viewCount + (it.viewCount == 1 ? " view" : " views")
                + " \u00b7 " + it.bidCount + (it.bidCount == 1 ? " bid" : " bids")
                + " \u00b7 " + it.code);
        ImageUtil.load(h.photo, it.firstPhoto(), 300);
        bindStatus(h, it);

        boolean ended = it.isEnded();
        h.edit.setVisibility(!it.hasBids() && !ended ? View.VISIBLE : View.GONE);
        h.end.setVisibility(!ended ? View.VISIBLE : View.GONE);
        boolean sold = ended && it.hasBids();
        h.fulfill.setVisibility(sold ? View.VISIBLE : View.GONE);
        h.fulfill.setText(it.fulfilled ? "Mark undelivered" : "Mark delivered");
        if (sold) {
            h.winner.setVisibility(View.VISIBLE);
            h.winner.setText("Won by " + (it.currentBidderName == null ? "a bidder" : it.currentBidderName)
                    + " \u00b7 " + (it.fulfilled ? "Delivered \u2713" : "Awaiting delivery"));
        } else {
            h.winner.setVisibility(View.GONE);
        }

        h.open.setOnClickListener(v -> cb.onOpen(it));
        h.edit.setOnClickListener(v -> cb.onEdit(it));
        h.end.setOnClickListener(v -> cb.onEnd(it));
        h.fulfill.setOnClickListener(v -> cb.onFulfill(it));
        h.delete.setOnClickListener(v -> cb.onDelete(it));
    }

    private void bindStatus(VH h, Item it) {
        if (it.isEnded()) {
            h.status.setText(it.hasBids() ? "SOLD" : "ENDED \u2014 NO BIDS");
        } else {
            h.status.setText(Fmt.timeLeft(it.endTime));
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final View open;
        final ImageView photo;
        final TextView title;
        final TextView price;
        final TextView status;
        final TextView meta;
        final TextView winner;
        final MaterialButton edit;
        final MaterialButton end;
        final MaterialButton fulfill;
        final MaterialButton delete;

        VH(View v) {
            super(v);
            open = v.findViewById(R.id.row_open);
            photo = v.findViewById(R.id.iv_photo);
            title = v.findViewById(R.id.tv_title);
            price = v.findViewById(R.id.tv_price);
            status = v.findViewById(R.id.tv_status);
            meta = v.findViewById(R.id.tv_meta);
            winner = v.findViewById(R.id.tv_winner);
            edit = v.findViewById(R.id.btn_edit);
            end = v.findViewById(R.id.btn_end);
            fulfill = v.findViewById(R.id.btn_fulfill);
            delete = v.findViewById(R.id.btn_delete);
        }
    }
}
