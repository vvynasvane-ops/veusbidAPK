package com.veus.veusbid.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;
import com.veus.veusbid.R;
import com.veus.veusbid.data.ProfileCache;
import com.veus.veusbid.data.UserStore;
import com.veus.veusbid.util.Fmt;
import com.veus.veusbid.util.ImageUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SettingsFragment extends Fragment implements UserStore.Listener {

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private String pendingPhoto = null;     // data URL picked but maybe not saved yet
    private boolean fieldsFilled = false;

    private TextView tvEmail;
    private TextView tvInitial;
    private ImageView ivAvatar;
    private TextInputEditText etName;
    private TextInputEditText etPhone;
    private TextInputEditText etOldPw;
    private TextInputEditText etNewPw;
    private CheckBox cbOnline;
    private TextView tvBlocked;
    private MaterialButton btnUnblock;

    private final ActivityResultLauncher<String> photoPicker =
            registerForActivityResult(new ActivityResultContracts.GetContent(), this::onPhotoPicked);

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle state) {
        super.onViewCreated(v, state);
        tvEmail = v.findViewById(R.id.tv_email);
        tvInitial = v.findViewById(R.id.tv_avatar_initial);
        ivAvatar = v.findViewById(R.id.iv_avatar);
        etName = v.findViewById(R.id.et_name);
        etPhone = v.findViewById(R.id.et_phone);
        etOldPw = v.findViewById(R.id.et_old_pw);
        etNewPw = v.findViewById(R.id.et_new_pw);
        cbOnline = v.findViewById(R.id.cb_online);
        tvBlocked = v.findViewById(R.id.tv_blocked);
        btnUnblock = v.findViewById(R.id.btn_unblock);

        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        tvEmail.setText(u == null || u.getEmail() == null ? "" : u.getEmail());

        v.findViewById(R.id.btn_photo).setOnClickListener(x -> photoPicker.launch("image/*"));
        v.findViewById(R.id.btn_save).setOnClickListener(x -> saveProfile());
        v.findViewById(R.id.btn_change_pw).setOnClickListener(x -> changePassword());
        btnUnblock.setOnClickListener(x -> UserStore.get().clearBlocked());
        v.findViewById(R.id.btn_logout).setOnClickListener(x -> signOut());
        v.findViewById(R.id.btn_delete).setOnClickListener(x -> showDeleteDialog());
        fieldsFilled = false;
        bindFromStore();
    }

    @Override
    public void onStart() {
        super.onStart();
        UserStore.get().addListener(this);
        bindFromStore();
    }

    @Override
    public void onStop() {
        UserStore.get().removeListener(this);
        super.onStop();
    }

    @Override
    public void onDestroy() {
        io.shutdown();
        super.onDestroy();
    }

    @Override
    public void onUserChanged() {
        bindFromStore();
    }

    private void bindFromStore() {
        if (etName == null) return;
        UserStore us = UserStore.get();
        // Fill editable fields once so a live snapshot never overwrites what you're typing.
        if (!fieldsFilled && us.uid != null && !us.name.isEmpty()) {
            fieldsFilled = true;
            etName.setText(us.name);
            etPhone.setText(us.phone);
            cbOnline.setChecked(us.showOnlineStatus);
        }
        String photo = pendingPhoto != null ? pendingPhoto : us.photoUrl;
        tvInitial.setText(Fmt.initial(etName.getText() == null || etName.getText().length() == 0
                ? us.name : etName.getText().toString()));
        ImageUtil.load(ivAvatar, photo == null || photo.isEmpty() ? null : photo, 240);
        int n = us.blocked.size();
        tvBlocked.setText(n == 0 ? "You haven't blocked anyone." : "Blocked sellers: " + n);
        btnUnblock.setVisibility(n == 0 ? View.GONE : View.VISIBLE);
    }

    private void onPhotoPicked(Uri uri) {
        if (uri == null) return;
        final android.content.ContentResolver cr = requireContext().getContentResolver();
        io.execute(() -> {
            try {
                final String data = ImageUtil.uriToDataUrl(cr, uri, 256, 70);
                if (getActivity() == null) return;
                getActivity().runOnUiThread(() -> {
                    if (!isAdded()) return;
                    pendingPhoto = data;
                    bindFromStore();
                    toast("Photo ready \u2014 tap Save profile to keep it.");
                });
            } catch (Exception | OutOfMemoryError e) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> toast("Couldn't process that image."));
                }
            }
        });
    }

    private String text(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString();
    }

    private void saveProfile() {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;
        String name = text(etName).trim();
        if (name.isEmpty()) {
            toast("Display name can't be empty.");
            return;
        }
        Map<String, Object> m = new HashMap<>();
        m.put("name", name);
        m.put("phone", text(etPhone).trim());
        m.put("showOnlineStatus", cbOnline.isChecked());
        if (pendingPhoto != null) m.put("photoURL", pendingPhoto);
        FirebaseFirestore.getInstance().collection("users").document(uid).update(m)
                .addOnSuccessListener(v -> {
                    pendingPhoto = null;
                    ProfileCache.clear();
                    toast("Profile saved.");
                })
                .addOnFailureListener(e -> toast("Couldn't save: " + e.getMessage()));
    }

    private boolean hasPasswordProvider(FirebaseUser u) {
        for (UserInfo info : u.getProviderData()) {
            if (EmailAuthProvider.PROVIDER_ID.equals(info.getProviderId())) return true;
        }
        return false;
    }

    private void changePassword() {
        final FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null || u.getEmail() == null) return;
        if (!hasPasswordProvider(u)) {
            toast("This account signs in with Google - change its password from Google.");
            return;
        }
        String oldPw = text(etOldPw);
        final String newPw = text(etNewPw);
        if (oldPw.isEmpty()) {
            toast("Enter your current password.");
            return;
        }
        if (newPw.length() < 6) {
            toast("New password must be at least 6 characters.");
            return;
        }
        AuthCredential cred = EmailAuthProvider.getCredential(u.getEmail(), oldPw);
        u.reauthenticate(cred).addOnCompleteListener(t -> {
            if (!t.isSuccessful()) {
                toast("Current password is wrong.");
                return;
            }
            u.updatePassword(newPw).addOnCompleteListener(t2 -> {
                if (t2.isSuccessful()) {
                    etOldPw.setText("");
                    etNewPw.setText("");
                    toast("Password changed.");
                } else {
                    toast("Couldn't change it: " + (t2.getException() == null ? "" : t2.getException().getMessage()));
                }
            });
        });
    }

    private void signOut() {
        UserStore.get().stop();
        ProfileCache.clear();
        FirebaseAuth.getInstance().signOut();
        Intent i = new Intent(requireContext(), AuthActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }

    // ---------------- delete account ----------------

    private void showDeleteDialog() {
        final FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) return;
        if (!hasPasswordProvider(u)) {
            toast("Google-signed accounts can be deleted from the VeusBid web app (Settings \u2192 Danger zone).");
            return;
        }
        View v = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_delete_account, null, false);
        final TextInputEditText word = v.findViewById(R.id.et_confirm_word);
        final TextInputEditText pw = v.findViewById(R.id.et_confirm_pw);
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete account")
                .setView(v)
                .setPositiveButton("Delete forever", (d, w) -> {
                    String typed = word.getText() == null ? "" : word.getText().toString().trim();
                    String pass = pw.getText() == null ? "" : pw.getText().toString();
                    if (!"DELETE".equals(typed)) {
                        toast("Type DELETE exactly to confirm.");
                        return;
                    }
                    if (pass.isEmpty()) {
                        toast("Enter your password.");
                        return;
                    }
                    deleteAccount(u, pass);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteAccount(final FirebaseUser u, String password) {
        final String uid = u.getUid();
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        u.reauthenticate(EmailAuthProvider.getCredential(u.getEmail(), password)).addOnCompleteListener(t -> {
            if (!t.isSuccessful()) {
                toast("Wrong password - nothing was deleted.");
                return;
            }
            // 1) your listings  2) your profile  3) the sign-in itself (order matters: rules need auth).
            db.collection("items").whereEqualTo("ownerUid", uid).get().addOnCompleteListener(q -> {
                if (!q.isSuccessful()) {
                    toast("Couldn't reach the server - nothing was deleted.");
                    return;
                }
                QuerySnapshot snap = q.getResult();
                WriteBatch batch = db.batch();
                int count = 0;
                if (snap != null) {
                    for (DocumentSnapshot d : snap.getDocuments()) {
                        if (count >= 450) break;
                        batch.delete(d.getReference());
                        count++;
                    }
                }
                batch.delete(db.collection("users").document(uid));
                batch.commit().addOnCompleteListener(b -> {
                    if (!b.isSuccessful()) {
                        toast("Couldn't delete your data - nothing else was removed.");
                        return;
                    }
                    u.delete().addOnCompleteListener(del -> {
                        UserStore.get().stop();
                        ProfileCache.clear();
                        if (!del.isSuccessful()) {
                            FirebaseAuth.getInstance().signOut();
                            toast("Your data was removed, but the sign-in couldn't be deleted. Sign in again and retry.");
                        } else {
                            toast("Account deleted.");
                        }
                        Intent i = new Intent(requireContext(), AuthActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                    });
                });
            });
        });
    }

    private void toast(String m) {
        if (isAdded()) Toast.makeText(requireContext(), m, Toast.LENGTH_LONG).show();
    }
}
