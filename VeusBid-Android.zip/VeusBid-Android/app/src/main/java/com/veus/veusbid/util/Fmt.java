package com.veus.veusbid.util;

import com.veus.veusbid.data.Item;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.Date;

public final class Fmt {

    public static String money(double n) {
        return "$" + new DecimalFormat("#,##0.##").format(n);
    }

    /** Bigger increments at higher price points, same table as the web app. */
    public static double minIncrement(double amount) {
        if (amount < 20) return 1;
        if (amount < 100) return 5;
        if (amount < 500) return 10;
        if (amount < 1000) return 25;
        if (amount < 5000) return 50;
        return 100;
    }

    public static double minNextBid(Item it) {
        double current = it.current();
        return it.bidCount > 0 ? current + minIncrement(current) : current;
    }

    /** "2d 4h left" / "3h 12m left" / "38m left" / "45s left" / "Auction ended". */
    public static String timeLeft(long endTime) {
        if (endTime <= 0) return "No end date";
        long diff = endTime - System.currentTimeMillis();
        if (diff <= 0) return "Auction ended";
        long secs = diff / 1000;
        long days = secs / 86400;
        long hours = (secs % 86400) / 3600;
        long mins = (secs % 3600) / 60;
        if (days > 0) return days + "d " + hours + "h left";
        if (hours > 0) return hours + "h " + mins + "m left";
        if (mins > 0) return mins + "m " + (secs % 60) + "s left";
        return secs + "s left";
    }

    public static String relative(long ms) {
        if (ms <= 0) return "";
        long diffMin = (System.currentTimeMillis() - ms) / 60000L;
        if (diffMin < 1) return "now";
        if (diffMin < 60) return diffMin + "m";
        if (diffMin < 1440) return (diffMin / 60) + "h";
        if (diffMin < 10080) return (diffMin / 1440) + "d";
        return DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(ms));
    }

    public static String clock(long ms) {
        if (ms <= 0) return "";
        return DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(ms));
    }

    public static String initial(String name) {
        if (name == null) return "?";
        String t = name.trim();
        return t.isEmpty() ? "?" : t.substring(0, 1).toUpperCase();
    }

    private Fmt() { }
}
