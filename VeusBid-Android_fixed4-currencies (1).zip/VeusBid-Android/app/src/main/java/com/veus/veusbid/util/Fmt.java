package com.veus.veusbid.util;

import com.veus.veusbid.data.Item;

import java.text.DateFormat;
import java.util.Date;

public final class Fmt {

    /** Legacy USD formatter, kept for any caller without a listing in hand. */
    public static String money(double n) {
        return Currency.format(n, Currency.DEFAULT);
    }

    /** Format an amount in the listing's own currency (KSh 12,500, $40, \u20A61,500...). */
    public static String money(double n, String currencyCode) {
        return Currency.format(n, currencyCode);
    }

    /**
     * The lowest bid that is accepted. There is NO forced increment: with bids on the board, any
     * amount strictly above the current bid is valid (the next smallest unit of the currency);
     * with no bids yet, the starting price itself is valid. What a bidder types is stored as-is.
     */
    public static double minNextBid(Item it) {
        double current = it.current();
        return it.bidCount > 0
                ? Currency.round(current + Currency.smallestUnit(it.currency), it.currency)
                : current;
    }

    /** "2d 4h left" / "3h 12m left" / "38m left" / "45s left" / "Auction ended". */
    public static String timeLeft(long endTime) {
        if (endTime <= 0) return "No end date";
        long diff = endTime - System.currentTimeMillis();
        if (diff <= 0) return "Auction ended";
        long secs = diff / 1000;
        long days = secs / 86400;
        long hours = (secs % 86400) / 3600;
        long mins = (secs % 3600) / 60;
        if (days > 0) return days + "d " + hours + "h left";
        if (hours > 0) return hours + "h " + mins + "m left";
        if (mins > 0) return mins + "m " + (secs % 60) + "s left";
        return secs + "s left";
    }

    public static String relative(long ms) {
        if (ms <= 0) return "";
        long diffMin = (System.currentTimeMillis() - ms) / 60000L;
        if (diffMin < 1) return "now";
        if (diffMin < 60) return diffMin + "m";
        if (diffMin < 1440) return (diffMin / 60) + "h";
        if (diffMin < 10080) return (diffMin / 1440) + "d";
        return DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(ms));
    }

    public static String clock(long ms) {
        if (ms <= 0) return "";
        return DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(ms));
    }

    public static String initial(String name) {
        if (name == null) return "?";
        String t = name.trim();
        return t.isEmpty() ? "?" : t.substring(0, 1).toUpperCase();
    }

    private Fmt() { }
}
