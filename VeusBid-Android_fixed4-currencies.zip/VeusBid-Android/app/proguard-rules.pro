# Release minification is off by default. Keep Firebase model classes if you turn it on.
-keepattributes Signature,*Annotation*
