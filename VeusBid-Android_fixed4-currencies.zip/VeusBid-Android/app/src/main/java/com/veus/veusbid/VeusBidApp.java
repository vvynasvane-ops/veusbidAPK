package com.veus.veusbid;

import android.app.Application;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.veus.veusbid.util.Notifier;

public class VeusBidApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        // With google-services.json the FirebaseInitProvider has already initialised the default app.
        if (FirebaseApp.getApps(this).isEmpty()) {
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setApiKey(FirebaseConfig.API_KEY)
                    .setApplicationId(FirebaseConfig.APP_ID)
                    .setProjectId(FirebaseConfig.PROJECT_ID)
                    .setStorageBucket(FirebaseConfig.STORAGE_BUCKET)
                    .setGcmSenderId(FirebaseConfig.SENDER_ID)
                    .build();
            FirebaseApp.initializeApp(this, options);
        }
        Notifier.ensureChannel(this);
    }
}
