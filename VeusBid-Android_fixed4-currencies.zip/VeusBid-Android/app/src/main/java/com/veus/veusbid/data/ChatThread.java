package com.veus.veusbid.data;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldPath;

import java.util.List;

/** threads/{uidA_uidB} inbox row. */
public class ChatThread {
    public String id = "";
    public String otherUid = "";
    public String lastText = "";
    public String lastFrom = "";
    public long lastAt = 0;
    public long myLastRead = 0;

    public static ChatThread from(DocumentSnapshot d, String myUid) {
        ChatThread t = new ChatThread();
        t.id = d.getId();
        Object parts = d.get("participants");
        if (parts instanceof List) {
            for (Object o : (List<?>) parts) {
                if (o instanceof String && !o.equals(myUid)) t.otherUid = (String) o;
            }
        }
        Object lt = d.get("lastText");
        t.lastText = lt instanceof String ? (String) lt : "";
        Object lf = d.get("lastFrom");
        t.lastFrom = lf instanceof String ? (String) lf : "";
        Object la = d.get("lastAt");
        if (la instanceof Timestamp) t.lastAt = ((Timestamp) la).toDate().getTime();
        Object lr = d.get(FieldPath.of("lastRead", myUid));
        if (lr instanceof Timestamp) t.myLastRead = ((Timestamp) lr).toDate().getTime();
        return t;
    }

    public boolean isUnread(String myUid) {
        if (lastAt == 0 || myUid.equals(lastFrom)) return false;
        return myLastRead == 0 || myLastRead < lastAt;
    }
}
