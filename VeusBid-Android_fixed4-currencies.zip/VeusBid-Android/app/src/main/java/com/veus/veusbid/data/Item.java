package com.veus.veusbid.data;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

/** One auction listing (items/{id}). Parsed by hand so Long/Double/null mixes never crash. */
public class Item {
    public String id = "";
    public String ownerUid = "";
    public String ownerName = "";
    public String title = "";
    public String category = "";
    public String condition = "";
    public String location = "";
    public String description = "";
    public String contact = "";
    public String code = "";
    public String currentBidderUid = null;
    public String currentBidderName = null;
    /** ISO code the whole auction is priced and bid in; legacy listings have none and read as USD. */
    public String currency = "USD";
    public double startingPrice = 0;
    public Double reservePrice = null;
    public Double currentBid = null;
    public long bidCount = 0;
    public long viewCount = 0;
    public long endTime = 0;
    public long createdAt = 0;
    public boolean fulfilled = false;
    public List<String> photos = new ArrayList<>();

    public static Item from(DocumentSnapshot d) {
        Item it = new Item();
        it.id = d.getId();
        it.ownerUid = str(d.get("ownerUid"));
        it.ownerName = str(d.get("ownerName"));
        it.title = str(d.get("title"));
        it.category = str(d.get("category"));
        it.condition = str(d.get("condition"));
        it.location = str(d.get("location"));
        it.description = str(d.get("description"));
        it.contact = str(d.get("contact"));
        it.code = str(d.get("code"));
        it.currency = com.veus.veusbid.util.Currency.get(str(d.get("currency"))).code;
        Object bidder = d.get("currentBidderUid");
        it.currentBidderUid = bidder instanceof String ? (String) bidder : null;
        Object bidderName = d.get("currentBidderName");
        it.currentBidderName = bidderName instanceof String ? (String) bidderName : null;
        Double sp = dbl(d.get("startingPrice"));
        it.startingPrice = sp == null ? 0 : sp;
        it.reservePrice = dbl(d.get("reservePrice"));
        it.currentBid = dbl(d.get("currentBid"));
        it.bidCount = lng(d.get("bidCount"));
        it.viewCount = lng(d.get("viewCount"));
        it.endTime = lng(d.get("endTime"));
        it.createdAt = lng(d.get("createdAt"));
        Object f = d.get("fulfilled");
        it.fulfilled = f instanceof Boolean && (Boolean) f;
        Object p = d.get("photos");
        if (p instanceof List) {
            for (Object o : (List<?>) p) {
                if (o instanceof String) it.photos.add((String) o);
            }
        }
        return it;
    }

    /** Price shown to everyone: highest bid if there is one, otherwise the starting price. */
    public double current() {
        return (currentBid != null && currentBid > 0) ? currentBid : startingPrice;
    }

    public boolean isEnded() {
        return endTime > 0 && endTime <= System.currentTimeMillis();
    }

    public boolean hasBids() {
        return bidCount > 0;
    }

    public String firstPhoto() {
        return photos.isEmpty() ? null : photos.get(0);
    }

    static String str(Object o) {
        return o instanceof String ? (String) o : "";
    }

    static Double dbl(Object o) {
        return o instanceof Number ? Double.valueOf(((Number) o).doubleValue()) : null;
    }

    static long lng(Object o) {
        return o instanceof Number ? ((Number) o).longValue() : 0L;
    }
}
