package com.veus.veusbid.data;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;

public class Message {
    public String id = "";
    public String from = "";
    public String text = "";
    /** 0 while the server timestamp is still pending (own just-sent message). */
    public long createdAt = 0;

    public static Message from(DocumentSnapshot d) {
        Message m = new Message();
        m.id = d.getId();
        Object f = d.get("from");
        m.from = f instanceof String ? (String) f : "";
        Object t = d.get("text");
        m.text = t instanceof String ? (String) t : "";
        Object c = d.get("createdAt");
        if (c instanceof Timestamp) m.createdAt = ((Timestamp) c).toDate().getTime();
        return m;
    }
}
