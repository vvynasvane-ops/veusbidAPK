package com.veus.veusbid.data;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

/** Small in-memory cache of other members' public profile (name + photo). */
public final class ProfileCache {

    public static final class Info {
        public final String name;
        public final String photo;
        public final boolean deleted;

        Info(String name, String photo, boolean deleted) {
            this.name = name;
            this.photo = photo;
            this.deleted = deleted;
        }
    }

    public interface Callback {
        void onInfo(Info info);
    }

    private static final Map<String, Info> CACHE = new HashMap<>();

    public static Info peek(String uid) {
        return CACHE.get(uid);
    }

    public static void get(final String uid, final Callback cb) {
        Info hit = CACHE.get(uid);
        if (hit != null) {
            cb.onInfo(hit);
            return;
        }
        FirebaseFirestore.getInstance().collection("users").document(uid).get()
                .addOnSuccessListener((DocumentSnapshot d) -> {
                    Info info;
                    if (d != null && d.exists()) {
                        Object n = d.get("name");
                        Object p = d.get("photoURL");
                        info = new Info(n instanceof String ? (String) n : "Member",
                                p instanceof String ? (String) p : "", false);
                    } else {
                        info = new Info("Deleted account", "", true);
                    }
                    CACHE.put(uid, info);
                    cb.onInfo(info);
                })
                .addOnFailureListener(e -> cb.onInfo(new Info("Member", "", false)));
    }

    public static void clear() {
        CACHE.clear();
    }

    private ProfileCache() { }
}
