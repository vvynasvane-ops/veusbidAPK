package com.veus.veusbid.data;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Live copy of the signed-in user's profile doc (users/{uid}): name, phone, photo,
 * watchlist (savedItems) and blocked sellers. Screens read it and re-render on change.
 */
public final class UserStore {

    public interface Listener {
        void onUserChanged();
    }

    private static final UserStore INSTANCE = new UserStore();

    public static UserStore get() {
        return INSTANCE;
    }

    public String uid = null;
    public String name = "";
    public String photoUrl = "";
    public String phone = "";
    public boolean showOnlineStatus = true;
    public final Set<String> saved = new HashSet<>();
    public final Set<String> blocked = new HashSet<>();

    private ListenerRegistration reg;
    private final List<Listener> listeners = new CopyOnWriteArrayList<>();

    private UserStore() { }

    public void addListener(Listener l) {
        if (!listeners.contains(l)) listeners.add(l);
    }

    public void removeListener(Listener l) {
        listeners.remove(l);
    }

    public void start(String newUid) {
        if (newUid.equals(uid) && reg != null) return;
        stop();
        uid = newUid;
        reg = FirebaseFirestore.getInstance().collection("users").document(newUid)
                .addSnapshotListener((DocumentSnapshot snap, FirebaseFirestoreException e) -> {
                    if (snap == null || !snap.exists()) return;
                    Object n = snap.get("name");
                    name = n instanceof String ? (String) n : "";
                    Object p = snap.get("photoURL");
                    photoUrl = p instanceof String ? (String) p : "";
                    Object ph = snap.get("phone");
                    phone = ph instanceof String ? (String) ph : "";
                    Object so = snap.get("showOnlineStatus");
                    showOnlineStatus = !(so instanceof Boolean) || (Boolean) so;
                    replace(saved, snap.get("savedItems"));
                    replace(blocked, snap.get("blockedUsers"));
                    fire();
                });
    }

    public void stop() {
        if (reg != null) reg.remove();
        reg = null;
        uid = null;
        name = "";
        photoUrl = "";
        phone = "";
        showOnlineStatus = true;
        saved.clear();
        blocked.clear();
    }

    public void setSaved(String itemId, boolean on) {
        if (uid == null) return;
        if (on) saved.add(itemId); else saved.remove(itemId);
        fire();
        FirebaseFirestore.getInstance().collection("users").document(uid)
                .update("savedItems", on ? FieldValue.arrayUnion(itemId) : FieldValue.arrayRemove(itemId));
    }

    public void block(String otherUid) {
        if (uid == null) return;
        blocked.add(otherUid);
        fire();
        FirebaseFirestore.getInstance().collection("users").document(uid)
                .update("blockedUsers", FieldValue.arrayUnion(otherUid));
    }

    public void clearBlocked() {
        if (uid == null) return;
        blocked.clear();
        fire();
        FirebaseFirestore.getInstance().collection("users").document(uid)
                .update("blockedUsers", new java.util.ArrayList<String>());
    }

    private void fire() {
        for (Listener l : listeners) l.onUserChanged();
    }

    private static void replace(Set<String> target, Object raw) {
        target.clear();
        if (raw instanceof List) {
            for (Object o : (List<?>) raw) {
                if (o instanceof String) target.add((String) o);
            }
        }
    }
}
