package com.veus.veusbid.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.OAuthProvider;
import androidx.core.content.ContextCompat;
import androidx.core.splashscreen.SplashScreen;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.NoCredentialException;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.veus.veusbid.FirebaseConfig;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.veus.veusbid.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/** Launcher screen: email/password log in, sign up, password reset. Forwards if already signed in. */
public class AuthActivity extends BaseActivity {

    private FirebaseAuth auth;
    private boolean signUp = false;

    private TextInputLayout tilName;
    private TextInputLayout tilConfirm;
    private TextInputEditText etName;
    private TextInputEditText etEmail;
    private TextInputEditText etPassword;
    private TextInputEditText etConfirm;
    private TextView errorView;
    private MaterialButton btnSubmit;
    private MaterialButton btnToggle;
    private MaterialButton btnForgot;
    private ProgressBar progress;
    private MaterialButton btnGoogle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SplashScreen.installSplashScreen(this);   // branded splash on every Android version
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) {
            goMain();
            return;
        }
        setContentView(R.layout.activity_auth);

        tilName = findViewById(R.id.til_name);
        tilConfirm = findViewById(R.id.til_confirm);
        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        etConfirm = findViewById(R.id.et_confirm);
        errorView = findViewById(R.id.auth_error);
        btnSubmit = findViewById(R.id.btn_submit);
        btnToggle = findViewById(R.id.btn_toggle);
        btnForgot = findViewById(R.id.btn_forgot);
        progress = findViewById(R.id.auth_progress);
        btnGoogle = findViewById(R.id.btn_google);
        findViewById(R.id.starfield).setVisibility(
                com.veus.veusbid.util.Appearance.starfield(this) ? View.VISIBLE : View.GONE);
        btnGoogle.setOnClickListener(v -> startGoogleSignIn());

        // If Android killed this screen while the browser-based Google sign-in was open, finish it here.
        com.google.android.gms.tasks.Task<com.google.firebase.auth.AuthResult> pending = auth.getPendingAuthResult();
        if (pending != null) {
            setBusy(true);
            pending.addOnSuccessListener(r -> {
                if (r.getUser() != null) ensureProfile(r.getUser(), null); else setBusy(false);
            }).addOnFailureListener(e -> {
                setBusy(false);
                showError(friendly(e));
            });
        }

        btnToggle.setOnClickListener(v -> {
            signUp = !signUp;
            applyMode();
        });
        btnSubmit.setOnClickListener(v -> submit());
        btnForgot.setOnClickListener(v -> sendReset());
        applyMode();
    }

    private void applyMode() {
        tilName.setVisibility(signUp ? View.VISIBLE : View.GONE);
        tilConfirm.setVisibility(signUp ? View.VISIBLE : View.GONE);
        btnForgot.setVisibility(signUp ? View.GONE : View.VISIBLE);
        btnSubmit.setText(signUp ? "Create account" : "Log in");
        btnToggle.setText(signUp ? "Already a member? Log in" : "New here? Create an account");
        showError(null);
    }

    private String text(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private void submit() {
        final String email = text(etEmail);
        final String password = etPassword.getText() == null ? "" : etPassword.getText().toString();
        final String name = text(etName);

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showError("Enter a valid email address.");
            return;
        }
        if (password.length() < 6) {
            showError("Password must be at least 6 characters.");
            return;
        }
        if (signUp) {
            if (TextUtils.isEmpty(name)) {
                showError("Pick a display name.");
                return;
            }
            String confirm = etConfirm.getText() == null ? "" : etConfirm.getText().toString();
            if (!password.equals(confirm)) {
                showError("Passwords don't match.");
                return;
            }
        }
        showError(null);
        setBusy(true);

        if (signUp) {
            auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
                if (!task.isSuccessful() || task.getResult() == null || task.getResult().getUser() == null) {
                    setBusy(false);
                    showError(friendly(task.getException()));
                    return;
                }
                final FirebaseUser user = task.getResult().getUser();
                UserProfileChangeRequest req = new UserProfileChangeRequest.Builder().setDisplayName(name).build();
                user.updateProfile(req).addOnCompleteListener(t -> ensureProfile(user, name));
            });
        } else {
            auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
                if (!task.isSuccessful() || task.getResult() == null || task.getResult().getUser() == null) {
                    setBusy(false);
                    showError(friendly(task.getException()));
                    return;
                }
                ensureProfile(task.getResult().getUser(), null);
            });
        }
    }

    /** Creates users/{uid} if it doesn't exist yet (new sign-up, or a deleted/missing profile). */
    private void ensureProfile(final FirebaseUser user, final String displayName) {
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("users").document(user.getUid()).get().addOnCompleteListener(task -> {
            DocumentSnapshot snap = task.isSuccessful() ? task.getResult() : null;
            if (snap != null && snap.exists()) {
                goMain();
                return;
            }
            Map<String, Object> pref = new HashMap<>();
            pref.put("priceMin", null);
            pref.put("priceMax", null);
            pref.put("category", "");
            pref.put("conditions", new ArrayList<String>());

            Map<String, Object> data = new HashMap<>();
            String nm = !TextUtils.isEmpty(displayName) ? displayName
                    : (user.getDisplayName() != null && !user.getDisplayName().isEmpty()
                    ? user.getDisplayName() : "New member");
            data.put("name", nm);
            data.put("photoURL", "");
            data.put("phone", "");
            data.put("showOnlineStatus", true);
            data.put("savedItems", new ArrayList<String>());
            data.put("blockedUsers", new ArrayList<String>());
            data.put("preferences", pref);
            data.put("createdAt", System.currentTimeMillis());
            db.collection("users").document(user.getUid()).set(data)
                    .addOnCompleteListener(t -> {
                        if (!t.isSuccessful()) {
                            Toast.makeText(this, "Signed in, but your profile couldn't be created yet. It will retry.",
                                    Toast.LENGTH_LONG).show();
                        }
                        goMain();
                    });
        });
    }

    // ---------------- Google sign-in ----------------

    private String webClientId() {
        // google-services.json (with Google sign-in enabled + SHA-1 registered) generates this string.
        int id = getResources().getIdentifier("default_web_client_id", "string", getPackageName());
        if (id != 0) return getString(id);
        return FirebaseConfig.WEB_CLIENT_ID;
    }

    private void startGoogleSignIn() {
        String clientId = webClientId();
        if (clientId == null || clientId.isEmpty()) {
            // No Web client ID configured: skip Credential Manager and use Firebase's own Google sign-in,
            // which needs nothing but the Google provider being enabled in Firebase Authentication.
            startGoogleWebFlow(null);
            return;
        }
        showError(null);
        setBusy(true);
        // Explicit "Sign in with Google" flow: always shows the account sheet, no silent auto-pick.
        GetSignInWithGoogleOption option = new GetSignInWithGoogleOption.Builder(clientId).build();
        GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(option).build();
        CredentialManager.create(this).getCredentialAsync(
                this, request, null, ContextCompat.getMainExecutor(this),
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override
                    public void onResult(GetCredentialResponse result) {
                        handleGoogleCredential(result.getCredential());
                    }

                    @Override
                    public void onError(GetCredentialException e) {
                        if (e instanceof GetCredentialCancellationException) {   // user closed the sheet
                            setBusy(false);
                            return;
                        }
                        // Credential Manager failed (SHA-1 / client-ID mismatch, no account, old Play services...).
                        // Fall back to Firebase's browser-based Google sign-in so the user can still get in.
                        startGoogleWebFlow(googleError(e));
                    }
                });
    }

    /** Fallback / default path: Firebase-hosted Google sign-in in a Custom Tab (no Web client ID needed). */
    private void startGoogleWebFlow(final String earlierProblem) {
        showError(null);
        setBusy(true);
        OAuthProvider.Builder provider = OAuthProvider.newBuilder("google.com");
        provider.addCustomParameter("prompt", "select_account");
        auth.startActivityForSignInWithProvider(this, provider.build())
                .addOnSuccessListener(result -> {
                    if (result.getUser() == null) {
                        setBusy(false);
                        showError("Google sign-in finished without an account. Please try again.");
                        return;
                    }
                    ensureProfile(result.getUser(), null);
                })
                .addOnFailureListener(e -> {
                    setBusy(false);
                    String msg = "Google sign-in failed" + (e.getMessage() == null ? "" : ": " + e.getMessage());
                    if (earlierProblem != null) msg += "\n\n" + earlierProblem;
                    msg += "\n\nFix: in Firebase console enable Authentication > Google, add this build's SHA-1 "
                            + "(run gradlew.bat signingReport) to the com.veus.veusbid Android app, download "
                            + "google-services.json into the app folder and rebuild. Email/password sign-in still works.";
                    showError(msg);
                });
    }

    private void handleGoogleCredential(Credential credential) {
        if (credential instanceof CustomCredential
                && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
            try {
                GoogleIdTokenCredential google = GoogleIdTokenCredential.createFrom(credential.getData());
                firebaseAuthWithGoogle(google.getIdToken());
            } catch (Exception e) {   // GoogleIdTokenParsingException is not declared as thrown in googleid 1.1.x
                setBusy(false);
                showError("Couldn't read Google's response. Please try again.");
            }
        } else {
            setBusy(false);
            showError("Unexpected sign-in response. Please try again.");
        }
    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential cred = GoogleAuthProvider.getCredential(idToken, null);
        auth.signInWithCredential(cred).addOnCompleteListener(task -> {
            if (!task.isSuccessful() || task.getResult() == null || task.getResult().getUser() == null) {
                setBusy(false);
                showError(friendly(task.getException()));
                return;
            }
            ensureProfile(task.getResult().getUser(), null);
        });
    }

    private String googleError(GetCredentialException e) {
        if (e instanceof NoCredentialException) {
            return "No Google account is available on this device. Add one in Android Settings and try again.";
        }
        return "Google sign-in failed" + (e.getMessage() == null ? "" : ": " + e.getMessage())
                + "\nIf this keeps happening, register this build's SHA-1 for com.veus.veusbid in Firebase and "
                + "re-download google-services.json.";
    }

    private void sendReset() {
        String email = text(etEmail);
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showError("Type your email above first, then tap Forgot password.");
            return;
        }
        setBusy(true);
        auth.sendPasswordResetEmail(email).addOnCompleteListener(task -> {
            setBusy(false);
            if (task.isSuccessful()) {
                showError(null);
                Toast.makeText(this, "Reset email sent - check your inbox.", Toast.LENGTH_LONG).show();
            } else {
                showError(friendly(task.getException()));
            }
        });
    }

    private void setBusy(boolean busy) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        btnGoogle.setEnabled(!busy);
        btnSubmit.setEnabled(!busy);
        btnToggle.setEnabled(!busy);
        btnForgot.setEnabled(!busy);
    }

    private void showError(String msg) {
        if (msg == null) {
            errorView.setVisibility(View.GONE);
        } else {
            errorView.setText(msg);
            errorView.setVisibility(View.VISIBLE);
        }
    }

    static String friendly(Exception e) {
        if (e instanceof FirebaseAuthWeakPasswordException) return "That password is too weak - try a longer one.";
        if (e instanceof FirebaseAuthUserCollisionException) return "An account with that email already exists.";
        if (e instanceof FirebaseAuthInvalidUserException) return "No account found for that email.";
        if (e instanceof FirebaseAuthInvalidCredentialsException) return "Wrong email or password.";
        if (e instanceof FirebaseNetworkException) return "Network error - check your connection and try again.";
        return e != null && e.getMessage() != null ? e.getMessage() : "Something went wrong. Try again.";
    }

    private void goMain() {
        Intent i = new Intent(this, MainActivity.class);
        String tab = getIntent().getStringExtra("tab");
        if (tab != null) i.putExtra("tab", tab);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
