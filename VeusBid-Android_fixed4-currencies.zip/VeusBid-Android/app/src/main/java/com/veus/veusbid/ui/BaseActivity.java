package com.veus.veusbid.ui;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.EdgeToEdge;
import androidx.activity.SystemBarStyle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.veus.veusbid.util.Appearance;
import com.veus.veusbid.util.FontStyler;
import com.veus.veusbid.util.Ui;

/**
 * Every screen extends this:
 *  - applies palette / accent / radius / font / size and light-dark mode,
 *  - draws edge-to-edge (mandatory when targeting Android 15+/16) and pads content by the system bars,
 *    display cutout and keyboard,
 *  - centres content in a readable column on tablets, foldables and desktop windows.
 */
public abstract class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Appearance.applyTheme(this);
        boolean light = Appearance.isLight(this);
        SystemBarStyle bars = light
                ? SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                : SystemBarStyle.dark(Color.TRANSPARENT);
        EdgeToEdge.enable(this, bars, bars);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onContentChanged() {
        super.onContentChanged();
        View content = findViewById(android.R.id.content);
        FontStyler.apply(content);

        if (content instanceof ViewGroup && ((ViewGroup) content).getChildCount() > 0) {
            final View root = ((ViewGroup) content).getChildAt(0);
            ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
                Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()
                        | WindowInsetsCompat.Type.displayCutout());
                Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
                onSystemInsets(root, bars, ime.bottom);
                return WindowInsetsCompat.CONSUMED;   // we handled them; children must not pad again
            });
            ViewCompat.requestApplyInsets(root);
        }
    }

    /** Default: pad the whole screen by the bars (+ keyboard) and centre it in a readable column. */
    protected void onSystemInsets(View root, Insets bars, int imeBottom) {
        int g = gutter();
        root.setPadding(bars.left + g, bars.top, bars.right + g, Math.max(bars.bottom, imeBottom));
    }

    /** Widest content column in dp before side gutters appear (tablets / foldables). */
    protected int maxContentWidthDp() {
        return 720;
    }

    protected int gutter() {
        int widthPx = getResources().getDisplayMetrics().widthPixels;
        int maxPx = Ui.dp(this, maxContentWidthDp());
        return Math.max(0, (widthPx - maxPx) / 2);
    }
}
