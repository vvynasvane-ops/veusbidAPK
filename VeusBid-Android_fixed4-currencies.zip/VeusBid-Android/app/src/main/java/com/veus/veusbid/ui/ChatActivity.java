package com.veus.veusbid.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.WriteBatch;
import com.veus.veusbid.R;
import com.veus.veusbid.data.Message;
import com.veus.veusbid.data.ProfileCache;
import com.veus.veusbid.util.Const;
import com.veus.veusbid.util.FontStyler;
import com.veus.veusbid.util.Fmt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** 1:1 chat. Thread id = sorted "uidA_uidB", identical to the web app, so both clients share threads. */
public class ChatActivity extends BaseActivity {

    private static final int TYPE_MINE = 0;
    private static final int TYPE_THEIRS = 1;

    private FirebaseFirestore db;
    private String myUid;
    private String otherUid;
    private String threadId;
    private DocumentReference threadRef;
    private boolean otherDeleted = false;

    private ListenerRegistration msgReg;
    private ListenerRegistration threadReg;
    private String lastMarkedId = "";
    private long otherLastRead = 0;
    private long lastMineAt = 0;

    private final List<Message> messages = new ArrayList<>();
    private MsgAdapter adapter;
    private RecyclerView rv;
    private TextView tvEmpty;
    private TextView tvSeen;
    private EditText etMessage;
    private ImageButton btnSend;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myUid = FirebaseAuth.getInstance().getUid();
        otherUid = getIntent().getStringExtra(Const.EXTRA_OTHER_UID);
        if (myUid == null || otherUid == null || otherUid.equals(myUid)) {
            finish();
            return;
        }
        db = FirebaseFirestore.getInstance();
        List<String> ids = Arrays.asList(myUid, otherUid);
        Collections.sort(ids);
        threadId = ids.get(0) + "_" + ids.get(1);
        threadRef = db.collection("threads").document(threadId);

        setContentView(R.layout.activity_chat);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
        String hint = getIntent().getStringExtra(Const.EXTRA_OTHER_NAME);
        toolbar.setTitle(hint == null || hint.isEmpty() ? "Chat" : hint);

        rv = findViewById(R.id.rv_messages);
        tvEmpty = findViewById(R.id.tv_chat_empty);
        tvSeen = findViewById(R.id.tv_seen);
        etMessage = findViewById(R.id.et_message);
        btnSend = findViewById(R.id.btn_send);

        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setStackFromEnd(true);
        rv.setLayoutManager(lm);
        adapter = new MsgAdapter();
        rv.setAdapter(adapter);

        String prefill = getIntent().getStringExtra(Const.EXTRA_PREFILL);
        if (prefill != null && savedInstanceState == null) {
            etMessage.setText(prefill);
            etMessage.setSelection(prefill.length());
        }
        btnSend.setOnClickListener(v -> send());

        ProfileCache.get(otherUid, info -> {
            if (isFinishing() || isDestroyed()) return;
            toolbar.setTitle(info.name);
            if (info.deleted) {
                otherDeleted = true;
                etMessage.setEnabled(false);
                etMessage.setHint("No longer on VeusBid");
                btnSend.setEnabled(false);
            }
        });

        // The rules only let you read a thread doc that exists and lists you as a participant,
        // so make sure it exists first (same trick as the web app). It stays out of the inbox
        // until a message is sent because it has no lastAt yet.
        Map<String, Object> init = new HashMap<>();
        init.put("participants", Arrays.asList(myUid, otherUid));
        Map<String, Object> lr = new HashMap<>();
        lr.put(myUid, FieldValue.serverTimestamp());
        init.put("lastRead", lr);
        threadRef.set(init, SetOptions.merge()).addOnCompleteListener(t -> {
            if (!isFinishing() && !isDestroyed()) attachListeners();
        });
    }

    private void attachListeners() {
        if (msgReg != null) return;
        msgReg = threadRef.collection("messages").orderBy("createdAt", Query.Direction.ASCENDING)
                .addSnapshotListener((QuerySnapshot snap, FirebaseFirestoreException e) -> {
                    if (snap == null) return;
                    messages.clear();
                    for (DocumentSnapshot d : snap.getDocuments()) messages.add(Message.from(d));
                    adapter.notifyDataSetChanged();
                    tvEmpty.setVisibility(messages.isEmpty() ? View.VISIBLE : View.GONE);
                    if (!messages.isEmpty()) rv.scrollToPosition(messages.size() - 1);

                    lastMineAt = 0;
                    for (Message m : messages) {
                        if (m.from.equals(myUid)) lastMineAt = m.createdAt;
                    }
                    updateSeen();

                    if (!messages.isEmpty()) {
                        Message last = messages.get(messages.size() - 1);
                        if (!last.from.equals(myUid) && !last.id.equals(lastMarkedId)) {
                            lastMarkedId = last.id;
                            markRead();
                        }
                    }
                });
        threadReg = threadRef.addSnapshotListener((DocumentSnapshot snap, FirebaseFirestoreException e) -> {
            if (snap == null || !snap.exists()) return;
            Object lr = snap.get(FieldPath.of("lastRead", otherUid));
            otherLastRead = lr instanceof Timestamp ? ((Timestamp) lr).toDate().getTime() : 0;
            updateSeen();
        });
    }

    private void updateSeen() {
        if (lastMineAt > 0 && otherLastRead >= lastMineAt && !messages.isEmpty()
                && messages.get(messages.size() - 1).from.equals(myUid)) {
            tvSeen.setText("Seen");
            tvSeen.setVisibility(View.VISIBLE);
        } else {
            tvSeen.setVisibility(View.GONE);
        }
    }

    private void markRead() {
        Map<String, Object> lr = new HashMap<>();
        lr.put(myUid, FieldValue.serverTimestamp());
        Map<String, Object> m = new HashMap<>();
        m.put("lastRead", lr);
        threadRef.set(m, SetOptions.merge());
    }

    private void send() {
        if (otherDeleted) return;
        final String text = etMessage.getText().toString().trim();
        if (text.isEmpty()) return;
        etMessage.setText("");
        btnSend.setEnabled(false);

        Map<String, Object> msg = new HashMap<>();
        msg.put("from", myUid);
        msg.put("to", otherUid);
        msg.put("text", text);
        msg.put("createdAt", FieldValue.serverTimestamp());

        Map<String, Object> lastRead = new HashMap<>();
        lastRead.put(myUid, FieldValue.serverTimestamp());
        Map<String, Object> thread = new HashMap<>();
        thread.put("participants", Arrays.asList(myUid, otherUid));
        thread.put("lastText", text);
        thread.put("lastFrom", myUid);
        thread.put("lastAt", FieldValue.serverTimestamp());
        thread.put("lastRead", lastRead);

        WriteBatch batch = db.batch();
        batch.set(threadRef.collection("messages").document(), msg);
        batch.set(threadRef, thread, SetOptions.merge());
        batch.commit().addOnCompleteListener(t -> {
            btnSend.setEnabled(!otherDeleted);
            if (!t.isSuccessful()) {
                // Don't lose the message: put it back so they can retry.
                etMessage.setText(text);
                etMessage.setSelection(text.length());
                Toast.makeText(this, "Couldn't send - check your connection and try again.", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (msgReg != null) msgReg.remove();
        if (threadReg != null) threadReg.remove();
        super.onDestroy();
    }

    private final class MsgAdapter extends RecyclerView.Adapter<MsgAdapter.VH> {
        @Override
        public int getItemViewType(int position) {
            return messages.get(position).from.equals(myUid) ? TYPE_MINE : TYPE_THEIRS;
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            int layout = viewType == TYPE_MINE ? R.layout.item_msg_mine : R.layout.item_msg_theirs;
            return new VH(LayoutInflater.from(parent.getContext()).inflate(layout, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Message m = messages.get(position);
            h.text.setText(m.text);
            h.time.setText(m.createdAt == 0 ? "sending..." : Fmt.clock(m.createdAt));
        }

        @Override
        public int getItemCount() {
            return messages.size();
        }

        final class VH extends RecyclerView.ViewHolder {
            final TextView text;
            final TextView time;

            VH(View v) {
                super(v);
                text = v.findViewById(R.id.tv_text);
                time = v.findViewById(R.id.tv_time);
                FontStyler.apply(v);
            }
        }
    }
}
