package com.veus.veusbid.ui;

import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.veus.veusbid.R;
import com.veus.veusbid.data.Item;
import com.veus.veusbid.data.UserStore;
import com.veus.veusbid.util.Const;
import com.veus.veusbid.util.Currency;
import com.veus.veusbid.util.ImageUtil;
import com.veus.veusbid.util.Ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Create a new auction, or edit one that has no bids yet (extra EXTRA_ITEM_ID => edit mode). */
public class EditListingActivity extends BaseActivity {

    private final List<String> photos = new ArrayList<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private String editingId = null;
    private boolean saving = false;

    private LinearLayout photoRow;
    private TextInputEditText etTitle;
    private TextInputEditText etStart;
    private TextInputEditText etReserve;
    private TextInputEditText etDuration;
    private TextInputEditText etLocation;
    private TextInputEditText etDescription;
    private TextInputEditText etContact;
    private Spinner spCategory;
    private Spinner spCondition;
    private Spinner spUnit;
    private Spinner spCurrency;
    private TextInputLayout tilStart;
    private TextInputLayout tilReserve;
    private View durationBox;
    private TextView tvDurationHint;
    private MaterialButton btnSave;
    private ProgressBar progress;

    private final ActivityResultLauncher<String> picker =
            registerForActivityResult(new ActivityResultContracts.GetMultipleContents(), this::onPicked);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            finish();
            return;
        }
        setContentView(R.layout.activity_edit_listing);

        MaterialToolbar tb = findViewById(R.id.toolbar);
        tb.setNavigationOnClickListener(v -> finish());

        photoRow = findViewById(R.id.photo_row);
        etTitle = findViewById(R.id.et_title);
        etStart = findViewById(R.id.et_start);
        etReserve = findViewById(R.id.et_reserve);
        etDuration = findViewById(R.id.et_duration);
        etLocation = findViewById(R.id.et_location);
        etDescription = findViewById(R.id.et_description);
        etContact = findViewById(R.id.et_contact);
        spCategory = findViewById(R.id.sp_category);
        spCondition = findViewById(R.id.sp_condition);
        spUnit = findViewById(R.id.sp_unit);
        spCurrency = findViewById(R.id.sp_currency);
        tilStart = findViewById(R.id.til_start);
        tilReserve = findViewById(R.id.til_reserve);
        durationBox = findViewById(R.id.duration_box);
        tvDurationHint = findViewById(R.id.tv_duration_hint);
        btnSave = findViewById(R.id.btn_save);
        progress = findViewById(R.id.progress);

        setupSpinner(spCategory, Const.CATEGORIES);
        setupSpinner(spCondition, Const.CONDITIONS);
        setupSpinner(spUnit, Const.DURATION_UNITS);
        setupSpinner(spCurrency, Currency.labels());
        spCurrency.setSelection(Currency.indexOf(Currency.preferred(this)));
        spCurrency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { updatePriceHints(); }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        updatePriceHints();

        TextWatcher hintWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { updateDurationHint(); }
        };
        etDuration.addTextChangedListener(hintWatcher);
        spUnit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { updateDurationHint(); }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        updateDurationHint();

        btnSave.setOnClickListener(v -> save());

        editingId = getIntent().getStringExtra(Const.EXTRA_ITEM_ID);
        if (editingId != null) {
            tb.setTitle("Edit listing");
            btnSave.setText("Save changes");
            durationBox.setVisibility(View.GONE);
            loadForEdit(editingId);
        }
        renderPhotos();
    }

    private void setupSpinner(Spinner sp, String[] values) {
        ArrayAdapter<String> a = new ArrayAdapter<>(this, R.layout.spinner_item, values);
        a.setDropDownViewResource(R.layout.spinner_dropdown);
        sp.setAdapter(a);
    }

    private String selectedCurrency() {
        return Currency.codeAt(Math.max(0, spCurrency.getSelectedItemPosition()));
    }

    private void updatePriceHints() {
        Currency.Cur c = Currency.get(selectedCurrency());
        tilStart.setHint("Starting price (" + c.symbol.trim() + ")");
        tilReserve.setHint("Reserve in " + c.code + " (optional)");
    }

    private long durationMs() {
        long n;
        try {
            String s = etDuration.getText() == null ? "" : etDuration.getText().toString().trim();
            n = s.isEmpty() ? 0 : Long.parseLong(s);
        } catch (NumberFormatException e) {
            n = 0;
        }
        int u = Math.max(0, Math.min(spUnit.getSelectedItemPosition(), Const.DURATION_UNIT_MS.length - 1));
        long ms = n * Const.DURATION_UNIT_MS[u];
        return Math.min(Const.MAX_DURATION_MS, Math.max(Const.MIN_DURATION_MS, ms));
    }

    private void updateDurationHint() {
        long mins = Math.round(durationMs() / 60000.0);
        String label;
        if (mins < 60) label = mins + (mins == 1 ? " minute" : " minutes");
        else if (mins < 1440) label = Math.round(mins / 60.0) + " hours";
        else label = Math.round(mins / 1440.0) + " days";
        tvDurationHint.setText("Ends about " + label + " after you publish (min 2 minutes, max 30 days).");
    }

    private void loadForEdit(String id) {
        setBusy(true);
        FirebaseFirestore.getInstance().collection("items").document(id).get()
                .addOnSuccessListener((DocumentSnapshot d) -> {
                    setBusy(false);
                    if (!d.exists()) {
                        Toast.makeText(this, "That listing no longer exists.", Toast.LENGTH_LONG).show();
                        finish();
                        return;
                    }
                    Item it = Item.from(d);
                    FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
                    if (u == null || !u.getUid().equals(it.ownerUid)) {
                        Toast.makeText(this, "You can only edit your own listings.", Toast.LENGTH_LONG).show();
                        finish();
                        return;
                    }
                    if (it.hasBids()) {
                        Toast.makeText(this, "This item already has bids and can't be edited.", Toast.LENGTH_LONG).show();
                        finish();
                        return;
                    }
                    etTitle.setText(it.title);
                    spCurrency.setSelection(Currency.indexOf(it.currency));
                    etStart.setText(num(it.startingPrice));
                    etReserve.setText(it.reservePrice == null ? "" : num(it.reservePrice));
                    etLocation.setText(it.location);
                    etDescription.setText(it.description);
                    etContact.setText(it.contact);
                    selectValue(spCategory, Const.CATEGORIES, it.category);
                    selectValue(spCondition, Const.CONDITIONS, it.condition);
                    photos.clear();
                    photos.addAll(it.photos);
                    renderPhotos();
                })
                .addOnFailureListener(e -> {
                    setBusy(false);
                    Toast.makeText(this, "Couldn't load the listing: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    finish();
                });
    }

    private static String num(double d) {
        return d == Math.floor(d) ? String.valueOf((long) d) : String.valueOf(d);
    }

    private static void selectValue(Spinner sp, String[] values, String v) {
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(v)) {
                sp.setSelection(i);
                return;
            }
        }
    }

    // ---------------- photos ----------------

    private void onPicked(List<Uri> uris) {
        if (uris == null || uris.isEmpty()) return;
        final int room = Const.MAX_PHOTOS - photos.size();
        if (room <= 0) {
            Toast.makeText(this, "You can attach up to " + Const.MAX_PHOTOS + " photos.", Toast.LENGTH_SHORT).show();
            return;
        }
        final List<Uri> take = uris.size() > room ? uris.subList(0, room) : uris;
        setBusy(true);
        io.execute(() -> {
            final List<String> done = new ArrayList<>();
            int failed = 0;
            for (Uri u : take) {
                try {
                    done.add(ImageUtil.uriToDataUrl(getContentResolver(), u, 640, 60));
                } catch (Exception | OutOfMemoryError e) {
                    failed++;
                }
            }
            final int failedCount = failed;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                photos.addAll(done);
                setBusy(false);
                renderPhotos();
                if (failedCount > 0) {
                    Toast.makeText(this, "Couldn't process " + failedCount + " image(s).", Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void renderPhotos() {
        photoRow.removeAllViews();
        for (int i = 0; i < photos.size(); i++) {
            final int index = i;
            FrameLayout frame = new FrameLayout(this);
            LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(dp(96), dp(96));
            flp.setMarginEnd(dp(8));
            frame.setLayoutParams(flp);

            ImageView iv = new ImageView(this);
            iv.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackgroundResource(R.drawable.bg_thumb);
            ImageUtil.load(iv, photos.get(i), 240);
            frame.addView(iv);

            ImageButton rm = new ImageButton(this);
            FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(dp(28), dp(28));
            rlp.gravity = android.view.Gravity.TOP | android.view.Gravity.END;
            rm.setLayoutParams(rlp);
            rm.setImageResource(R.drawable.ic_close);
            rm.setBackgroundResource(R.drawable.bg_badge);
            rm.setPadding(dp(4), dp(4), dp(4), dp(4));
            rm.setColorFilter(Ui.color(this, R.attr.vbAccent));
            rm.setContentDescription(getString(R.string.cd_remove));
            rm.setOnClickListener(v -> {
                if (index < photos.size()) photos.remove(index);
                renderPhotos();
            });
            frame.addView(rm);
            photoRow.addView(frame);
        }
        if (photos.size() < Const.MAX_PHOTOS) {
            ImageButton add = new ImageButton(this);
            add.setLayoutParams(new LinearLayout.LayoutParams(dp(96), dp(96)));
            add.setImageResource(R.drawable.ic_add_photo);
            add.setBackgroundResource(R.drawable.bg_card);
            add.setColorFilter(Ui.color(this, R.attr.vbAccent));
            add.setContentDescription("Add photos");
            add.setOnClickListener(v -> picker.launch("image/*"));
            photoRow.addView(add);
        }
    }

    // ---------------- save ----------------

    private String text(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private Double number(TextInputEditText et) {
        String s = text(et);
        if (s.isEmpty()) return null;
        try {
            return Double.valueOf(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void setBusy(boolean busy) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        btnSave.setEnabled(!busy && !saving);
    }

    private void save() {
        if (saving) return;
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;

        final String title = text(etTitle);
        final Double start = number(etStart);
        final Double reserve = number(etReserve);
        if (title.isEmpty()) {
            toast("Give the item a title first.");
            return;
        }
        if (start == null || start <= 0) {
            toast("Set a starting price above " + Currency.format(0, selectedCurrency()) + ".");
            return;
        }
        if (reserve != null && reserve < start) {
            toast("The reserve can't be lower than the starting price.");
            return;
        }
        if (editingId == null && text(etDuration).isEmpty()) {
            toast("Set an auction length greater than 0.");
            return;
        }
        int total = 0;
        for (String p : photos) total += p.length();
        if (total > Const.MAX_PHOTO_CHARS_TOTAL) {
            toast("Photos are too large together - remove one or two.");
            return;
        }

        Map<String, Object> fields = new HashMap<>();
        fields.put("title", title);
        fields.put("category", Const.CATEGORIES[Math.max(0, spCategory.getSelectedItemPosition())]);
        fields.put("condition", Const.CONDITIONS[Math.max(0, spCondition.getSelectedItemPosition())]);
        fields.put("currency", selectedCurrency());
        Currency.remember(this, selectedCurrency());
        fields.put("startingPrice", start);
        fields.put("reservePrice", reserve);
        fields.put("location", text(etLocation));
        fields.put("description", text(etDescription));
        fields.put("contact", text(etContact));
        fields.put("photos", new ArrayList<>(photos));

        saving = true;
        btnSave.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        if (editingId != null) {
            db.collection("items").document(editingId).update(fields)
                    .addOnSuccessListener(v -> {
                        toast("Listing updated.");
                        finish();
                    })
                    .addOnFailureListener(this::onSaveFailed);
        } else {
            String ownerName = UserStore.get().name;
            if (ownerName == null || ownerName.isEmpty()) {
                ownerName = user.getDisplayName() != null && !user.getDisplayName().isEmpty()
                        ? user.getDisplayName() : "A seller";
            }
            long now = System.currentTimeMillis();
            fields.put("ownerUid", user.getUid());
            fields.put("ownerName", ownerName);
            fields.put("code", Const.newListingCode());
            fields.put("currentBid", null);
            fields.put("currentBidderUid", null);
            fields.put("currentBidderName", null);
            fields.put("bidCount", 0L);
            fields.put("everBidUids", new ArrayList<String>());
            fields.put("viewCount", 0L);
            fields.put("fulfilled", false);
            fields.put("createdAt", now);
            fields.put("endTime", now + durationMs());
            db.collection("items").add(fields)
                    .addOnSuccessListener(ref -> {
                        toast("Auction started!");
                        finish();
                    })
                    .addOnFailureListener(this::onSaveFailed);
        }
    }

    private void onSaveFailed(Exception e) {
        saving = false;
        btnSave.setEnabled(true);
        progress.setVisibility(View.GONE);
        toast("Couldn't save: " + e.getMessage());
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        io.shutdown();
        super.onDestroy();
    }
}
