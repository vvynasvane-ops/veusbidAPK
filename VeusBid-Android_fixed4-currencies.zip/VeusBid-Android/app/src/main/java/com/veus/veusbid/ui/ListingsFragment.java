package com.veus.veusbid.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QuerySnapshot;
import com.veus.veusbid.R;
import com.veus.veusbid.data.Item;
import com.veus.veusbid.util.Const;
import com.veus.veusbid.util.FontStyler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** "Sell" tab: everything the signed-in user has listed, with end-now / delete / delivered controls. */
public class ListingsFragment extends Fragment implements MyListingAdapter.Callbacks {

    private MyListingAdapter adapter;
    private TextView tvEmpty;
    private TextView tvSummary;
    private ListenerRegistration reg;
    private final List<Item> mine = new ArrayList<>();
    private final Handler ticker = new Handler(Looper.getMainLooper());

    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            if (adapter != null) adapter.tick();
            ticker.postDelayed(this, 1000);
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        return inflater.inflate(R.layout.fragment_listings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        super.onViewCreated(view, state);
        tvEmpty = view.findViewById(R.id.tv_my_empty);
        tvSummary = view.findViewById(R.id.tv_my_summary);
        RecyclerView rv = view.findViewById(R.id.rv_my_items);
        adapter = new MyListingAdapter(this);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        rv.setAdapter(adapter);
        rv.setItemAnimator(null);
        ExtendedFloatingActionButton fab = view.findViewById(R.id.fab_new);
        fab.setOnClickListener(v -> startActivity(new Intent(requireContext(), EditListingActivity.class)));
        FontStyler.apply(view);
    }

    @Override
    public void onStart() {
        super.onStart();
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid != null && reg == null) {
            reg = FirebaseFirestore.getInstance().collection("items")
                    .whereEqualTo("ownerUid", uid)
                    .addSnapshotListener((QuerySnapshot snap, FirebaseFirestoreException e) -> {
                        if (e != null) {
                            tvEmpty.setText("Couldn't load your listings: " + e.getMessage());
                            tvEmpty.setVisibility(View.VISIBLE);
                            return;
                        }
                        if (snap == null) return;
                        mine.clear();
                        for (DocumentSnapshot d : snap.getDocuments()) mine.add(Item.from(d));
                        Collections.sort(mine, (a, b) -> Long.compare(b.createdAt, a.createdAt));
                        adapter.submit(mine);
                        tvEmpty.setText("You haven't listed anything yet.\nTap \"List an item\" to start an auction.");
                        tvEmpty.setVisibility(mine.isEmpty() ? View.VISIBLE : View.GONE);
                        int live = 0;
                        for (Item it : mine) if (!it.isEnded()) live++;
                        tvSummary.setText(mine.size() + " total \u00b7 " + live + " live");
                    });
        }
        ticker.removeCallbacks(tickRunnable);
        ticker.postDelayed(tickRunnable, 1000);
    }

    @Override
    public void onStop() {
        ticker.removeCallbacks(tickRunnable);
        super.onStop();
    }

    @Override
    public void onDestroyView() {
        if (reg != null) reg.remove();
        reg = null;
        super.onDestroyView();
    }

    @Override
    public void onOpen(Item it) {
        Intent i = new Intent(requireContext(), ItemActivity.class);
        i.putExtra(Const.EXTRA_ITEM_ID, it.id);
        startActivity(i);
    }

    @Override
    public void onEdit(Item it) {
        if (it.hasBids()) {
            Toast.makeText(requireContext(), "This item already has bids and can't be edited - you can still delete it.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        Intent i = new Intent(requireContext(), EditListingActivity.class);
        i.putExtra(Const.EXTRA_ITEM_ID, it.id);
        startActivity(i);
    }

    @Override
    public void onEnd(final Item it) {
        String msg = it.hasBids()
                ? "End \"" + it.title + "\" right now? The current highest bid becomes the winning bid immediately."
                : "End \"" + it.title + "\" right now with no bids? It will close as unsold.";
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("End auction")
                .setMessage(msg)
                .setPositiveButton("End now", (d, w) ->
                        FirebaseFirestore.getInstance().collection("items").document(it.id)
                                .update("endTime", System.currentTimeMillis())
                                .addOnFailureListener(e -> toast("Couldn't end it: " + e.getMessage())))
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onFulfill(Item it) {
        FirebaseFirestore.getInstance().collection("items").document(it.id)
                .update("fulfilled", !it.fulfilled)
                .addOnFailureListener(e -> toast("Couldn't update: " + e.getMessage()));
    }

    @Override
    public void onDelete(final Item it) {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete listing")
                .setMessage("Permanently delete \"" + it.title + "\"? This can't be undone.")
                .setPositiveButton("Delete", (d, w) ->
                        FirebaseFirestore.getInstance().collection("items").document(it.id).delete()
                                .addOnFailureListener(e -> toast("Couldn't delete: " + e.getMessage())))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toast(String msg) {
        if (isAdded()) Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show();
    }
}
