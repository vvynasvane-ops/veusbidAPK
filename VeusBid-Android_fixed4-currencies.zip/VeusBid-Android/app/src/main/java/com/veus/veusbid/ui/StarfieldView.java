package com.veus.veusbid.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

import com.veus.veusbid.R;
import com.veus.veusbid.util.Ui;

import java.util.Random;

/** Slowly drifting, twinkling stars tinted by the current palette. Pauses when hidden/detached. */
public class StarfieldView extends View {

    private static final int COUNT = 64;
    private final float[] x = new float[COUNT];   // 0..1
    private final float[] y = new float[COUNT];   // 0..1
    private final float[] speed = new float[COUNT];
    private final float[] size = new float[COUNT];
    private final float[] phase = new float[COUNT];
    private final boolean[] bright = new boolean[COUNT];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int accent;
    private int soft;
    private long last = 0;

    public StarfieldView(Context c) {
        this(c, null);
    }

    public StarfieldView(Context c, AttributeSet a) {
        super(c, a);
        Random r = new Random(7);
        for (int i = 0; i < COUNT; i++) {
            x[i] = r.nextFloat();
            y[i] = r.nextFloat();
            speed[i] = 0.004f + r.nextFloat() * 0.012f;   // screens per second
            size[i] = 0.6f + r.nextFloat() * 1.4f;
            phase[i] = r.nextFloat() * 6.28f;
            bright[i] = r.nextInt(5) == 0;
        }
        accent = Ui.color(c, R.attr.vbAccent);
        soft = Ui.color(c, R.attr.vbText);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        long now = SystemClock.uptimeMillis();
        float dt = last == 0 ? 0f : Math.min(0.1f, (now - last) / 1000f);
        last = now;
        float w = getWidth();
        float h = getHeight();
        float density = getResources().getDisplayMetrics().density;
        for (int i = 0; i < COUNT; i++) {
            y[i] += speed[i] * dt;
            if (y[i] > 1f) {
                y[i] -= 1f;
            }
            float tw = 0.5f + 0.5f * (float) Math.sin(now / 900.0 + phase[i]);
            int base = bright[i] ? accent : soft;
            int alpha = (int) ((bright[i] ? 120 : 70) * (0.35f + 0.65f * tw));
            paint.setColor((base & 0x00FFFFFF) | (alpha << 24));
            canvas.drawCircle(x[i] * w, y[i] * h, size[i] * density, paint);
        }
        if (isShown()) postInvalidateOnAnimation();
    }

    @Override
    protected void onVisibilityChanged(View changed, int visibility) {
        super.onVisibilityChanged(changed, visibility);
        last = 0;
        if (visibility == VISIBLE) postInvalidateOnAnimation();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        last = 0;
        postInvalidateOnAnimation();
    }
}
