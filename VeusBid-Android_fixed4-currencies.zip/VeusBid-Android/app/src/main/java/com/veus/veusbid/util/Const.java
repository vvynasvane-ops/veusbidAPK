package com.veus.veusbid.util;

import java.util.Random;

/** Shared constants - mirror the web app's common.js so both clients describe items the same way. */
public final class Const {
    public static final String[] CATEGORIES = {
            "Electronics", "Collectibles", "Fashion & Accessories", "Home & Living",
            "Vehicles & Parts", "Sports & Outdoors", "Art & Antiques", "Books & Media",
            "Toys & Games", "Musical Instruments", "Jewelry & Watches", "Other"
    };

    public static final String[] CONDITIONS = {"New", "Like new", "Good", "Fair", "For parts"};

    public static final String[] FEEDBACK_PRESETS = {
            "Item as described", "Fast shipping", "Great communication", "Well packaged",
            "Would buy again", "Smooth transaction", "Slow to respond", "Not as described"
    };

    public static final String[] DURATION_UNITS = {"minutes", "hours", "days"};
    public static final long[] DURATION_UNIT_MS = {60_000L, 3_600_000L, 86_400_000L};

    /** A bid inside this window before close pushes the close out by the same amount. */
    public static final long SNIPE_WINDOW_MS = 2 * 60 * 1000L;
    public static final long MIN_DURATION_MS = 2 * 60 * 1000L;
    public static final long MAX_DURATION_MS = 30L * 24 * 60 * 60 * 1000L;

    public static final int MAX_PHOTOS = 6;
    /** Firestore documents cap at 1 MiB; photos are stored inline as base64, so budget them. */
    public static final int MAX_PHOTO_CHARS_TOTAL = 850_000;

    public static final String EXTRA_ITEM_ID = "itemId";
    public static final String EXTRA_OTHER_UID = "otherUid";
    public static final String EXTRA_OTHER_NAME = "otherName";
    public static final String EXTRA_PREFILL = "prefill";

    private static final Random RNG = new Random();

    public static String newListingCode() {
        return "VB-" + (100000 + RNG.nextInt(900000));
    }

    private Const() { }
}
