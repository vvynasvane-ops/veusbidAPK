package com.veus.veusbid.util;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Currencies a seller can list in. Each listing carries its own ISO code ("currency" field on the
 * Firestore item); everything is bid in that currency. Listings from before this feature have no
 * field and read as USD, so old data (and the web app) keep working.
 *
 * perUsd is a ROUGH reference rate (units of this currency per 1 USD). It is only used for
 * "about" conversions, price sorting across currencies, and scaling bid steps. It is never used
 * to settle a bid. Edit the numbers below whenever you want fresher approximations.
 */
public final class Currency {

    public static final class Cur {
        public final String code;
        public final String symbol;
        public final String name;
        public final String country;   // ISO country for the flag emoji
        public final int decimals;     // max fraction digits shown
        public final double perUsd;

        Cur(String code, String symbol, String name, String country, int decimals, double perUsd) {
            this.code = code;
            this.symbol = symbol;
            this.name = name;
            this.country = country;
            this.decimals = decimals;
            this.perUsd = perUsd;
        }

        public String flag() {
            if (country.length() != 2) return "";
            int a = Character.codePointAt(country, 0) - 'A' + 0x1F1E6;
            int b = Character.codePointAt(country, 1) - 'A' + 0x1F1E6;
            return new String(Character.toChars(a)) + new String(Character.toChars(b));
        }

        /** "🇰🇪  KES · Kenyan Shilling" - used in pickers. */
        public String label() {
            return flag() + "  " + code + " \u00b7 " + name;
        }
    }

    public static final String DEFAULT = "USD";
    private static final String PREFS = "veusbid_currency";
    private static final String KEY_LAST = "last";

    private static final Map<String, Cur> TABLE = new LinkedHashMap<>();

    private static void add(String code, String symbol, String name, String country, int dec, double perUsd) {
        TABLE.put(code, new Cur(code, symbol, name, country, dec, perUsd));
    }

    static {
        // East Africa first, then the rest of Africa, then the world.
        add("KES", "KSh", "Kenyan Shilling", "KE", 2, 129);
        add("UGX", "USh", "Ugandan Shilling", "UG", 0, 3650);
        add("TZS", "TSh", "Tanzanian Shilling", "TZ", 0, 2550);
        add("RWF", "FRw", "Rwandan Franc", "RW", 0, 1450);
        add("ETB", "Br", "Ethiopian Birr", "ET", 2, 125);
        add("NGN", "\u20A6", "Nigerian Naira", "NG", 2, 1500);
        add("GHS", "GH\u20B5", "Ghanaian Cedi", "GH", 2, 15);
        add("ZAR", "R", "South African Rand", "ZA", 2, 18);
        add("EGP", "E\u00A3", "Egyptian Pound", "EG", 2, 48);
        add("MAD", "MAD", "Moroccan Dirham", "MA", 2, 9.5);
        add("ZMW", "ZK", "Zambian Kwacha", "ZM", 2, 26);
        add("XOF", "CFA", "West African CFA Franc", "SN", 0, 600);
        add("USD", "$", "US Dollar", "US", 2, 1);
        add("EUR", "\u20AC", "Euro", "EU", 2, 0.92);
        add("GBP", "\u00A3", "British Pound", "GB", 2, 0.78);
        add("CHF", "CHF", "Swiss Franc", "CH", 2, 0.88);
        add("CAD", "C$", "Canadian Dollar", "CA", 2, 1.38);
        add("AUD", "A$", "Australian Dollar", "AU", 2, 1.52);
        add("AED", "AED", "UAE Dirham", "AE", 2, 3.67);
        add("SAR", "SAR", "Saudi Riyal", "SA", 2, 3.75);
        add("TRY", "\u20BA", "Turkish Lira", "TR", 2, 34);
        add("INR", "\u20B9", "Indian Rupee", "IN", 2, 84);
        add("PKR", "Rs", "Pakistani Rupee", "PK", 2, 280);
        add("BDT", "\u09F3", "Bangladeshi Taka", "BD", 2, 120);
        add("CNY", "CN\u00A5", "Chinese Yuan", "CN", 2, 7.2);
        add("JPY", "\u00A5", "Japanese Yen", "JP", 0, 150);
        add("KRW", "\u20A9", "South Korean Won", "KR", 0, 1370);
        add("SGD", "S$", "Singapore Dollar", "SG", 2, 1.33);
        add("IDR", "Rp", "Indonesian Rupiah", "ID", 0, 15800);
        add("PHP", "\u20B1", "Philippine Peso", "PH", 2, 57);
        add("BRL", "R$", "Brazilian Real", "BR", 2, 5.5);
        add("MXN", "MX$", "Mexican Peso", "MX", 2, 19);
    }

    public static List<Cur> all() {
        return new ArrayList<>(TABLE.values());
    }

    /** Unknown / empty codes fall back to USD so a bad value in Firestore can never crash a screen. */
    public static Cur get(String code) {
        Cur c = code == null ? null : TABLE.get(code.trim().toUpperCase(Locale.ROOT));
        return c != null ? c : TABLE.get(DEFAULT);
    }

    public static boolean isKnown(String code) {
        return code != null && TABLE.containsKey(code.trim().toUpperCase(Locale.ROOT));
    }

    public static int indexOf(String code) {
        int i = 0;
        String want = get(code).code;
        for (String k : TABLE.keySet()) {
            if (k.equals(want)) return i;
            i++;
        }
        return 0;
    }

    public static String[] labels() {
        String[] out = new String[TABLE.size()];
        int i = 0;
        for (Cur c : TABLE.values()) out[i++] = c.label();
        return out;
    }

    public static String codeAt(int index) {
        int i = 0;
        for (String k : TABLE.keySet()) {
            if (i++ == index) return k;
        }
        return DEFAULT;
    }

    // ---------------- formatting ----------------

    /** 12500 KES -> "KSh 12,500"; 12.5 USD -> "$12.5"; 1500 NGN -> "\u20A61,500". */
    public static String format(double amount, String code) {
        Cur c = get(code);
        StringBuilder pattern = new StringBuilder("#,##0");
        if (c.decimals > 0) {
            pattern.append('.');
            for (int i = 0; i < c.decimals; i++) pattern.append('#');
        }
        DecimalFormat df = new DecimalFormat(pattern.toString(), DecimalFormatSymbols.getInstance(Locale.US));
        String num = df.format(amount);
        char last = c.symbol.charAt(c.symbol.length() - 1);
        boolean spaced = Character.isLetter(last) && !c.symbol.equals("R$");
        return c.symbol + (spaced ? " " : "") + num;
    }

    // ---------------- approximate conversion ----------------

    public static double convert(double amount, String from, String to) {
        return amount / get(from).perUsd * get(to).perUsd;
    }

    public static double toUsd(double amount, String from) {
        return amount / get(from).perUsd;
    }

    // ---------------- bid steps ----------------

    private static final double[] NICE = {1, 2, 2.5, 5, 10};

    /**
     * USD keeps the original table exactly. Other currencies take that same step, scale it by the
     * rate (so KSh 129 is roughly $1) and round to a friendly 1 / 2 / 2.5 / 5 x 10^n number.
     * Zero-decimal currencies never step below 1.
     */
    public static double scaleIncrement(double usdStep, String code) {
        Cur c = get(code);
        if (c.code.equals("USD")) return usdStep;
        double raw = usdStep * c.perUsd;
        double exp = Math.floor(Math.log10(raw));
        double base = Math.pow(10, exp);
        double m = raw / base;
        double best = NICE[0];
        double bestDiff = Double.MAX_VALUE;
        for (double n : NICE) {
            double d = Math.abs(Math.log(m / n));
            if (d < bestDiff) {
                bestDiff = d;
                best = n;
            }
        }
        double step = best * base;
        double floor = c.decimals == 0 ? 1 : 0.01;
        return Math.max(step, floor);
    }

    // ---------------- device / user preference ----------------

    /** Last currency the user listed in, else their phone's locale currency, else USD. */
    public static String preferred(Context ctx) {
        try {
            SharedPreferences p = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String saved = p.getString(KEY_LAST, null);
            if (isKnown(saved)) return get(saved).code;
        } catch (Exception ignored) {
            // fall through to locale
        }
        try {
            java.util.Currency lc = java.util.Currency.getInstance(Locale.getDefault());
            if (lc != null && isKnown(lc.getCurrencyCode())) return get(lc.getCurrencyCode()).code;
        } catch (Exception ignored) {
            // locale without a currency
        }
        return DEFAULT;
    }

    public static void remember(Context ctx, String code) {
        try {
            ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(KEY_LAST, get(code).code).apply();
        } catch (Exception ignored) {
            // best effort
        }
    }

    private Currency() { }
}
