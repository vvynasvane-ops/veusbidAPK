package com.veus.veusbid.util;

import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputLayout;
import com.veus.veusbid.R;

/**
 * Applies the chosen font family and text-size scale to a view tree. Each TextView is stamped once
 * (tag_font_applied) so re-running on the same tree never compounds the size scale.
 */
public final class FontStyler {

    public static void apply(View root) {
        if (root == null) return;
        if (Appearance.isDefaultTypography(root.getContext())) return;
        float scale = Appearance.scale(root.getContext());
        walk(root, root.getContext(), scale);
    }

    private static void walk(View v, android.content.Context c, float scale) {
        if (v instanceof TextInputLayout) {
            ((TextInputLayout) v).setTypeface(Appearance.typeface(c, Typeface.NORMAL));
        }
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            if (tv.getTag(R.id.tag_font_applied) == null) {
                tv.setTag(R.id.tag_font_applied, Boolean.TRUE);
                Typeface cur = tv.getTypeface();
                int style = cur == null ? Typeface.NORMAL : cur.getStyle();
                tv.setTypeface(Appearance.typeface(c, style));
                if (scale != 1f) {
                    tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, tv.getTextSize() * scale);
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), c, scale);
        }
    }

    private FontStyler() { }
}
