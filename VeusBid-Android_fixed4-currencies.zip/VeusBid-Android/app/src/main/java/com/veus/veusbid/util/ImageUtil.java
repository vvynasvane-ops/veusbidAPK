package com.veus.veusbid.util;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.LruCache;
import android.widget.ImageView;

import com.veus.veusbid.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Photos live on Firestore documents as "data:image/jpeg;base64,..." strings (no Firebase Storage,
 * no billing plan) - the same format the web app writes. This class converts both ways and loads
 * them into ImageViews off the main thread with an in-memory cache.
 */
public final class ImageUtil {

    private static final ExecutorService POOL = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final LruCache<String, Bitmap> CACHE;

    static {
        int maxKb = (int) (Runtime.getRuntime().maxMemory() / 1024L);
        CACHE = new LruCache<String, Bitmap>(Math.max(4 * 1024, maxKb / 8)) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return value.getByteCount() / 1024;
            }
        };
    }

    /** Reads an image Uri, fixes EXIF rotation, downsizes to maxDim and returns a JPEG data URL. */
    public static String uriToDataUrl(ContentResolver cr, Uri uri, int maxDim, int quality) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        InputStream in = cr.openInputStream(uri);
        if (in == null) throw new IOException("Cannot open image");
        try {
            BitmapFactory.decodeStream(in, null, bounds);
        } finally {
            in.close();
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IOException("Not an image");

        int sample = 1;
        while ((bounds.outWidth / sample) > maxDim * 2 || (bounds.outHeight / sample) > maxDim * 2) {
            sample *= 2;
        }
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        Bitmap bmp;
        in = cr.openInputStream(uri);
        if (in == null) throw new IOException("Cannot open image");
        try {
            bmp = BitmapFactory.decodeStream(in, null, opts);
        } finally {
            in.close();
        }
        if (bmp == null) throw new IOException("Could not decode image");

        int rotation = 0;
        InputStream exifIn = null;
        try {
            exifIn = cr.openInputStream(uri);
            if (exifIn != null) {
                ExifInterface exif = new ExifInterface(exifIn);
                int o = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (o == ExifInterface.ORIENTATION_ROTATE_90) rotation = 90;
                else if (o == ExifInterface.ORIENTATION_ROTATE_180) rotation = 180;
                else if (o == ExifInterface.ORIENTATION_ROTATE_270) rotation = 270;
            }
        } catch (Exception ignored) {
            // No EXIF is fine.
        } finally {
            if (exifIn != null) {
                try { exifIn.close(); } catch (IOException ignored) { }
            }
        }

        float scale = Math.min(1f, (float) maxDim / (float) Math.max(bmp.getWidth(), bmp.getHeight()));
        Matrix m = new Matrix();
        if (scale < 1f) m.postScale(scale, scale);
        if (rotation != 0) m.postRotate(rotation);
        Bitmap out = bmp;
        if (!m.isIdentity()) {
            out = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
        }

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        out.compress(Bitmap.CompressFormat.JPEG, quality, bos);
        if (out != bmp) out.recycle();
        bmp.recycle();
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
    }

    /** Decodes a data URL (or bare base64) to a Bitmap no larger than ~reqPx. Null if invalid. */
    public static Bitmap decodeDataUrl(String dataUrl, int reqPx) {
        if (dataUrl == null || dataUrl.isEmpty()) return null;
        int comma = dataUrl.indexOf(',');
        String b64 = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
        byte[] bytes;
        try {
            bytes = Base64.decode(b64, Base64.DEFAULT);
        } catch (IllegalArgumentException e) {
            return null;
        }
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
        if (bounds.outWidth <= 0) return null;
        int sample = 1;
        while ((bounds.outWidth / (sample * 2)) >= reqPx && (bounds.outHeight / (sample * 2)) >= reqPx) {
            sample *= 2;
        }
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
    }

    /** Async load into an ImageView; safe with RecyclerView recycling. Null dataUrl shows the placeholder. */
    public static void load(final ImageView iv, final String dataUrl, final int reqPx) {
        if (dataUrl == null || dataUrl.isEmpty()) {
            iv.setTag(R.id.tag_image_key, null);
            iv.setImageDrawable(null);
            return;
        }
        final String key = dataUrl.length() + ":" + dataUrl.hashCode() + ":" + reqPx;
        iv.setTag(R.id.tag_image_key, key);
        Bitmap cached = CACHE.get(key);
        if (cached != null) {
            iv.setImageBitmap(cached);
            return;
        }
        iv.setImageDrawable(null);
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                final Bitmap bmp;
                try {
                    bmp = decodeDataUrl(dataUrl, reqPx);
                } catch (OutOfMemoryError oom) {
                    return;
                }
                if (bmp == null) return;
                CACHE.put(key, bmp);
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        Object tag = iv.getTag(R.id.tag_image_key);
                        if (key.equals(tag)) iv.setImageBitmap(bmp);
                    }
                });
            }
        });
    }

    private ImageUtil() { }
}
