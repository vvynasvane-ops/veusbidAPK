package com.veus.veusbid.util;

import android.content.Context;
import android.util.TypedValue;

public final class Ui {
    /** Resolves a theme colour attribute (e.g. R.attr.vbAccent) against the context's current theme. */
    public static int color(Context c, int attr) {
        TypedValue tv = new TypedValue();
        c.getTheme().resolveAttribute(attr, tv, true);
        return tv.data;
    }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    /** CONFIRM / REJECT haptics on Android 11+, a plain click/long-press elsewhere. */
    public static void haptic(android.view.View v, boolean success) {
        int type;
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            type = success ? android.view.HapticFeedbackConstants.CONFIRM : android.view.HapticFeedbackConstants.REJECT;
        } else {
            type = success ? android.view.HapticFeedbackConstants.CONTEXT_CLICK : android.view.HapticFeedbackConstants.LONG_PRESS;
        }
        v.performHapticFeedback(type);
    }

    private Ui() { }
}
