@echo off
rem Fast incremental debug build (no clean).
cd /d "%~dp0"
call setup_wrapper.bat
call gradlew.bat assembleDebug
