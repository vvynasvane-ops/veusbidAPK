@echo off
rem Full clean + debug build. Usage: clean_build.bat
cd /d "%~dp0"

call setup_wrapper.bat

call gradlew.bat --stop
call gradlew.bat clean
if errorlevel 1 goto :fail

call gradlew.bat assembleDebug
if errorlevel 1 goto :fail

echo.
echo BUILD OK  ->  app\build\outputs\apk\debug\app-debug.apk
exit /b 0

:fail
echo.
echo BUILD FAILED - scroll up for the first "What went wrong" block.
exit /b 1
