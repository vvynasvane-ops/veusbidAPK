@echo off
rem One-time / repair setup: wrapper jar + local.properties. Safe to re-run.
cd /d "%~dp0"

if not exist gradle\wrapper mkdir gradle\wrapper

if not exist gradle\wrapper\gradle-wrapper.jar (
  echo Downloading gradle-wrapper.jar for Gradle 8.13 ...
  curl -L -o gradle\wrapper\gradle-wrapper.jar ^
    https://github.com/gradle/gradle/raw/v8.13.0/gradle/wrapper/gradle-wrapper.jar
)

if not exist local.properties (
  echo sdk.dir=C\:\\Users\\Lenovo\\AppData\\Local\\Android\\Sdk> local.properties
  echo Wrote local.properties
)

echo Setup done.
