# VeusBid — native Android (Java + XML)

Native port of the VeusBid web app (live auctions) on the **same Firebase project and Firestore schema**,
so Android and web users share listings, bids, chats and profiles.

- Java 17 source level, XML layouts, Material 3 dark theme (plasma-cyan `#00FFD4` / ultraviolet `#7B2FFF` on void black)
- **minSdk 26 · compileSdk/targetSdk 36 (Android 16) · AGP 8.13.2 · Gradle 8.13 · Firebase BoM 34.17.0** (Auth + Firestore only)
- Runs on Android 8.0 → 17; meets Google Play's "new apps and updates must target API 36" rule (Aug 31, 2026)
- No Firebase Storage / billing needed: photos are compressed JPEG data-URLs inside the item document, like the web app

## 1. One-time setup
1. `setup_wrapper.bat` (downloads `gradle-wrapper.jar` if missing, writes `local.properties` with your SDK path).
   The jar is already bundled, so normally nothing happens.
2. SDK: install **Android SDK Platform 36** + Build-Tools 36.x (SDK Manager). JDK 17-24 works (JDK 21 recommended).
3. **Firebase (recommended):** Firebase console → project `veusbid` → add an **Android app** with package
   `com.veus.veusbid` → add your debug SHA-1 → download `google-services.json` into `app/`.
   The build detects it automatically. Without it the app still builds and falls back to the web config in
   `FirebaseConfig.java` (works for Email/Password + Firestore, but if your web API key is restricted to
   websites you'll get "API key not valid" — then do the step above).
4. Firebase console → Authentication: Email/Password enabled.
5. **Publish the bundled `firestore.rules`** (see "Rules fix" below) and deploy `firestore.indexes.json`
   (`firebase deploy --only firestore:indexes`) so the Messages inbox works.

## 2. Build (Windows)
```
clean_build.bat          :: clean + assembleDebug (also runs setup_wrapper.bat)
build_debug.bat          :: incremental debug build
gradlew.bat clean
gradlew.bat assembleDebug
```
APK: `app\build\outputs\apk\debug\app-debug.apk`

If JDK 23 gives toolchain / `jlink` / `JdkImageTransform` errors, install JDK 17 or 21 and uncomment
`org.gradle.java.home` in `gradle.properties`.

## 3. What's implemented (parity map)
| Area | Android |
|---|---|
| Auth | Email/password sign-up (confirm password), log in, forgot-password email, auto profile-doc repair |
| Browse | Live Firestore listener, search (title/category/description/code), sort (5 modes), filters (category, price range, condition, ending ≤1h, has photo, watchlist only, include ended), ticking countdowns, blocked sellers hidden, watch heart |
| Item page | Photo pager, live price/bid count/countdown, min-increment table, **transactional** bid + bid-history write, 2-minute anti-snipe, bid history (live), feedback chips + list, share, calendar reminder, report, block, message seller, seller contact |
| Sell | Create (title, category, condition, start price, reserve, length in min/hours/days, location, description, contact, ≤6 photos), edit until first bid, delete, **End now**, mark delivered, winner shown |
| After sale | Seller "Message winner" with delivery template; winner "Share my delivery details" |
| Messages | Inbox (unread dot, search, deleted-account handling), chat with seen tick, send-failure restore, shared thread ids with web |
| Account | Name/phone/photo, online-status toggle, change password (re-auth), blocked list, sign out, delete account (items → profile → auth) |
| Google sign-in | "Continue with Google" on the login screen (classic `GoogleSignInClient` + Firebase credential). Same Firebase users as the web app; account chooser always shown; signs out of Google on logout |
| Appearance | Account → Appearance: **Mode: Match system / Light / Dark**, 7 palettes (each with a tuned light and dark version), 8 accent colours, 8 font styles, 4 text sizes, 3 corner styles, animated starfield, live preview card, reset |
| Alerts | In-app + system notification when you're outbid (while the app is open) |

Not ported (kept out to stay stable): typing indicator,
chat PIN lock, theme/RGB customiser, recommendations/saved presets, background push (needs FCM + backend).

## 4. Rules fix (important)
The original rule for a bid required `currentBid > startingPrice` even on the **first** bid, but both UIs allow a
first bid equal to the starting price, so that bid was rejected with PERMISSION_DENIED. The bundled
`firestore.rules` accepts `>= startingPrice` for the first bid and `> currentBid` afterwards; everything else is unchanged.
Bids are written in one Firestore transaction (price check + item update + bid record), closing the web app's
documented race condition.

## 5. Layout
```
app/src/main/java/com/veus/veusbid/
  VeusBidApp, FirebaseConfig
  data/  Item, ChatThread, Message, UserStore, ProfileCache, OutbidWatcher
  util/  Const, Fmt, ImageUtil, Notifier
  ui/    AuthActivity, MainActivity, BrowseFragment(+AuctionAdapter), ListingsFragment(+MyListingAdapter),
         EditListingActivity, ItemActivity, MessagesFragment, ChatActivity, SettingsFragment
```

## 6. Google sign-in setup (required once)
1. Firebase console → Authentication → Sign-in method → **Google → Enable** (set a support email).
2. Get your debug SHA-1: `gradlew.bat signingReport` (look for `Variant: debug` → SHA1), or
   `keytool -list -v -keystore %USERPROFILE%\.android\debug.keystore -alias androiddebugkey -storepass android`.
3. Project settings → your Android app (`com.veus.veusbid`) → **Add fingerprint** → paste the SHA-1
   (add the release SHA-1 later too).
4. Download a fresh `google-services.json` into `app/` (it now contains the Web client the build uses).
   Alternative without the file: paste the Web client ID into `FirebaseConfig.WEB_CLIENT_ID`.
5. Rebuild. Error code 10 on the button = SHA-1 / package mismatch; fix step 3.

Accounts that signed in with Google can change their password and delete their account from the web app
(those two actions need a password re-auth that Google accounts don't have in-app).

## 7. Appearance system (how it works)
Every colour in layouts/drawables is a theme attribute (`?attr/vbAccent`, `vbBg`, ...). A choice in
Account → Appearance is saved in SharedPreferences and layered onto the theme before each screen is created:
`Palette.* → Accent.* → Radius.*` (see `values/themes.xml`, `util/Appearance.java`). Fonts use Android's built-in
families (no downloads); `FontStyler` applies family + text-size scale to each screen. Add your own palette by
copying one `Palette.*` style and adding a row to `Appearance.PALETTES`.

### Light / dark mode
Account → Appearance → **Mode**. Default is Dark; *Match system* follows the phone's day/night setting live.
Light mode uses the Material 3 *light* base theme (`Theme.VeusBid.Light`) plus a `PaletteLight.*` overlay and a darker
`AccentLight.*` set, so text keeps proper contrast; status/navigation bar icons flip automatically.

## 8. Built for new devices (v2.0)
| Feature | What it does |
|---|---|
| **Target API 36** | Satisfies Play's Aug-2026 rule; no deprecated opt-outs |
| **Edge-to-edge** | Draws behind status/gesture bars (mandatory on Android 15+/16); content is inset by bars, display cutout and keyboard; bottom nav floats above the gesture bar and hides while typing |
| **Adaptive layouts** | Content is centred in a readable column on tablets/foldables/desktop windows; Browse grid grows from 2 to 4+ columns with window width; no orientation locks (ignored on large screens in API 36+) |
| **Predictive back** | `enableOnBackInvokedCallback` on — system back-peek animations work |
| **Credential Manager** | "Continue with Google" now uses Credential Manager (`GetSignInWithGoogleOption`); the old GoogleSignIn client Google deprecated is gone |
| **Material You palette** | Android 12+: palette follows your wallpaper, in light and dark |
| **Themed icon** | Android 13+ monochrome launcher icon follows the wallpaper theme |
| **Splash screen** | Branded splash on every version (core-splashscreen) |
| **Launcher shortcuts** | Long-press the icon: List an item · Messages · Live auctions |
| **Haptics** | Confirm / reject vibration on bids (Android 11+) |
| **16 KB page-size ready** | No native code of our own; all dependencies are current releases |
| **Notifications** | Android 13+ runtime permission handled; outbid alerts via a high-importance channel |

Upgrading from v1: nothing to migrate (same package, same Firestore data). Delete the old `.gradle` folder once if Android Studio
complains about the wrapper, then run `clean_build.bat`.
