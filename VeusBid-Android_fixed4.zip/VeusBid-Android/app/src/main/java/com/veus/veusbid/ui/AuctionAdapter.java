package com.veus.veusbid.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.veus.veusbid.R;
import com.veus.veusbid.data.Item;
import com.veus.veusbid.data.UserStore;
import com.veus.veusbid.util.FontStyler;
import com.veus.veusbid.util.Fmt;
import com.veus.veusbid.util.ImageUtil;

import java.util.ArrayList;
import java.util.List;

/** Grid card adapter for Browse. A "tick" payload refreshes only the countdown text. */
public class AuctionAdapter extends RecyclerView.Adapter<AuctionAdapter.VH> {

    public interface Callbacks {
        void onOpen(Item item);
    }

    private static final Object TICK = new Object();

    private final List<Item> data = new ArrayList<>();
    private final Callbacks callbacks;

    public AuctionAdapter(Callbacks callbacks) {
        this.callbacks = callbacks;
        setHasStableIds(true);
    }

    public void submit(List<Item> items) {
        data.clear();
        data.addAll(items);
        notifyDataSetChanged();
    }

    public List<Item> items() {
        return data;
    }

    public void tick() {
        if (!data.isEmpty()) notifyItemRangeChanged(0, data.size(), TICK);
    }

    @Override
    public long getItemId(int position) {
        return data.get(position).id.hashCode();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_auction_card, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position, @NonNull List<Object> payloads) {
        if (!payloads.isEmpty()) {
            bindCountdown(h, data.get(position));
            return;
        }
        super.onBindViewHolder(h, position, payloads);
    }

    @Override
    public void onBindViewHolder(@NonNull final VH h, int position) {
        final Item it = data.get(position);
        h.title.setText(it.title.isEmpty() ? "Untitled item" : it.title);
        h.price.setText(Fmt.money(it.current()));
        String bids = it.bidCount + (it.bidCount == 1 ? " bid" : " bids");
        h.meta.setText(bids + " \u00b7 " + it.condition);
        bindCountdown(h, it);
        ImageUtil.load(h.photo, it.firstPhoto(), 400);

        final boolean watching = UserStore.get().saved.contains(it.id);
        h.heart.setImageResource(watching ? R.drawable.ic_heart : R.drawable.ic_heart_outline);
        h.heart.setOnClickListener(v -> UserStore.get().setSaved(it.id, !UserStore.get().saved.contains(it.id)));
        h.itemView.setOnClickListener(v -> callbacks.onOpen(it));
    }

    private void bindCountdown(VH h, Item it) {
        h.countdown.setText(it.isEnded() ? "ENDED" : Fmt.timeLeft(it.endTime).toUpperCase());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final ImageView photo;
        final TextView countdown;
        final ImageButton heart;
        final TextView title;
        final TextView price;
        final TextView meta;

        VH(View v) {
            super(v);
            photo = v.findViewById(R.id.iv_photo);
            countdown = v.findViewById(R.id.tv_countdown);
            heart = v.findViewById(R.id.btn_heart);
            title = v.findViewById(R.id.tv_title);
            price = v.findViewById(R.id.tv_price);
            meta = v.findViewById(R.id.tv_meta);
            FontStyler.apply(v);
        }
    }
}
