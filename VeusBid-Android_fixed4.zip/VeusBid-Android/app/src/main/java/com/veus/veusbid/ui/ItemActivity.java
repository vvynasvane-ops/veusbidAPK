package com.veus.veusbid.ui;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.CalendarContract;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.Transaction;
import com.veus.veusbid.R;
import com.veus.veusbid.data.Item;
import com.veus.veusbid.data.UserStore;
import com.veus.veusbid.util.Const;
import com.veus.veusbid.util.Fmt;
import com.veus.veusbid.util.FontStyler;
import com.veus.veusbid.util.ImageUtil;
import com.veus.veusbid.util.Ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** The auction floor: live price, countdown, bid form, history, messaging, feedback, report/block. */
public class ItemActivity extends BaseActivity implements UserStore.Listener {

    private FirebaseFirestore db;
    private FirebaseUser me;
    private String itemId;
    private Item item;
    private boolean viewCounted = false;
    private boolean lastEnded = false;
    private boolean placingBid = false;

    private ListenerRegistration itemReg;
    private ListenerRegistration bidsReg;
    private ListenerRegistration feedbackReg;
    private final Handler ticker = new Handler(Looper.getMainLooper());

    private MaterialToolbar toolbar;
    private View content;
    private RecyclerView rvPhotos;
    private PhotoAdapter photoAdapter;
    private TextView tvPhotoCount;
    private TextView tvNoPhoto;
    private TextView tvTitle;
    private TextView tvSub;
    private TextView tvPriceLabel;
    private TextView tvPrice;
    private TextView tvBids;
    private TextView tvCountdown;
    private TextView tvStatus;
    private View bidBox;
    private TextInputLayout tilBid;
    private TextInputEditText etBid;
    private MaterialButton btnBid;
    private MaterialButton btnMessage;
    private MaterialButton btnSecond;
    private MaterialButton btnFeedback;
    private LinearLayout bidHistory;
    private TextView tvNoBids;
    private TextView tvDesc;
    private TextView tvSeller;
    private TextView tvContact;
    private TextView tvFeedbackHeader;
    private LinearLayout feedbackList;

    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            if (item != null) {
                if (item.isEnded() != lastEnded) render(); else updateCountdown();
            }
            ticker.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        me = FirebaseAuth.getInstance().getCurrentUser();
        itemId = getIntent().getStringExtra(Const.EXTRA_ITEM_ID);
        if (me == null || itemId == null) {
            finish();
            return;
        }
        db = FirebaseFirestore.getInstance();
        setContentView(R.layout.activity_item);

        toolbar = findViewById(R.id.toolbar);
        toolbar.inflateMenu(R.menu.menu_item);
        toolbar.setNavigationOnClickListener(v -> finish());
        toolbar.setOnMenuItemClickListener(this::onMenu);

        content = findViewById(R.id.content);
        rvPhotos = findViewById(R.id.rv_photos);
        tvPhotoCount = findViewById(R.id.tv_photo_count);
        tvNoPhoto = findViewById(R.id.tv_no_photo);
        tvTitle = findViewById(R.id.tv_title);
        tvSub = findViewById(R.id.tv_sub);
        tvPriceLabel = findViewById(R.id.tv_price_label);
        tvPrice = findViewById(R.id.tv_price);
        tvBids = findViewById(R.id.tv_bids);
        tvCountdown = findViewById(R.id.tv_countdown);
        tvStatus = findViewById(R.id.tv_status);
        bidBox = findViewById(R.id.bid_box);
        tilBid = findViewById(R.id.til_bid);
        etBid = findViewById(R.id.et_bid);
        btnBid = findViewById(R.id.btn_bid);
        btnMessage = findViewById(R.id.btn_message);
        btnSecond = findViewById(R.id.btn_second);
        btnFeedback = findViewById(R.id.btn_feedback);
        bidHistory = findViewById(R.id.bid_history);
        tvNoBids = findViewById(R.id.tv_no_bids);
        tvDesc = findViewById(R.id.tv_desc);
        tvSeller = findViewById(R.id.tv_seller);
        tvContact = findViewById(R.id.tv_contact);
        tvFeedbackHeader = findViewById(R.id.tv_feedback_header);
        feedbackList = findViewById(R.id.feedback_list);

        final LinearLayoutManager lm = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        rvPhotos.setLayoutManager(lm);
        photoAdapter = new PhotoAdapter();
        rvPhotos.setAdapter(photoAdapter);
        new PagerSnapHelper().attachToRecyclerView(rvPhotos);
        rvPhotos.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView rv, int dx, int dy) {
                updatePhotoCounter(lm.findFirstVisibleItemPosition());
            }
        });

        btnBid.setOnClickListener(v -> placeBid());
        btnFeedback.setOnClickListener(v -> showFeedbackPicker());
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (me == null || itemId == null) return;
        UserStore.get().addListener(this);
        if (itemReg == null) startListeners();
        ticker.removeCallbacks(tickRunnable);
        ticker.postDelayed(tickRunnable, 1000);
    }

    @Override
    protected void onStop() {
        ticker.removeCallbacks(tickRunnable);
        UserStore.get().removeListener(this);
        stopListeners();
        super.onStop();
    }

    private void startListeners() {
        DocumentReference ref = db.collection("items").document(itemId);
        itemReg = ref.addSnapshotListener((DocumentSnapshot snap, FirebaseFirestoreException e) -> {
            if (e != null) {
                Toast.makeText(this, "Couldn't load this listing: " + e.getMessage(), Toast.LENGTH_LONG).show();
                return;
            }
            if (snap == null) return;
            if (!snap.exists()) {
                Toast.makeText(this, "This listing was removed.", Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            item = Item.from(snap);
            content.setVisibility(View.VISIBLE);
            if (!viewCounted) {
                viewCounted = true;
                if (!item.ownerUid.equals(me.getUid())) {
                    // Rules allow any member to change ONLY viewCount. Failure is harmless.
                    db.collection("items").document(itemId).update("viewCount", FieldValue.increment(1));
                }
            }
            render();
        });

        bidsReg = ref.collection("bids").orderBy("at", Query.Direction.DESCENDING).limit(50)
                .addSnapshotListener((QuerySnapshot snap, FirebaseFirestoreException e) -> {
                    if (snap == null) return;
                    renderBids(snap.getDocuments());
                });

        feedbackReg = db.collection("feedback").whereEqualTo("itemId", itemId)
                .addSnapshotListener((QuerySnapshot snap, FirebaseFirestoreException e) -> {
                    if (snap == null) return;
                    renderFeedback(snap.getDocuments());
                });
    }

    private void stopListeners() {
        if (itemReg != null) itemReg.remove();
        if (bidsReg != null) bidsReg.remove();
        if (feedbackReg != null) feedbackReg.remove();
        itemReg = null;
        bidsReg = null;
        feedbackReg = null;
    }

    @Override
    public void onUserChanged() {
        updateWatchIcon();
    }

    // ---------------- rendering ----------------

    private boolean isOwner() {
        return item != null && item.ownerUid.equals(me.getUid());
    }

    private boolean iAmLeader() {
        return item != null && item.currentBidderUid != null && item.currentBidderUid.equals(me.getUid());
    }

    private void render() {
        if (item == null) return;
        final boolean owner = isOwner();
        final boolean ended = item.isEnded();
        lastEnded = ended;

        toolbar.setTitle(item.title.isEmpty() ? "Auction" : item.title);
        tvTitle.setText(item.title.isEmpty() ? "Untitled item" : item.title);

        StringBuilder sub = new StringBuilder();
        sub.append(item.category);
        if (!item.condition.isEmpty()) sub.append(" \u00b7 ").append(item.condition);
        if (!item.location.isEmpty()) sub.append(" \u00b7 ").append(item.location);
        if (!item.code.isEmpty()) sub.append(" \u00b7 ").append(item.code);
        tvSub.setText(sub.toString());

        if (!photoAdapter.sameAs(item.photos)) {
            photoAdapter.set(item.photos);
        }
        boolean hasPhotos = !item.photos.isEmpty();
        tvNoPhoto.setVisibility(hasPhotos ? View.GONE : View.VISIBLE);
        tvPhotoCount.setVisibility(item.photos.size() > 1 ? View.VISIBLE : View.GONE);
        updatePhotoCounter(0);

        tvPriceLabel.setText(item.hasBids() ? "CURRENT BID" : "STARTING PRICE");
        tvPrice.setText(Fmt.money(item.current()));
        StringBuilder bids = new StringBuilder();
        bids.append(item.bidCount).append(item.bidCount == 1 ? " bid" : " bids");
        if (owner && item.reservePrice != null) {
            boolean met = item.hasBids() && item.current() >= item.reservePrice;
            bids.append(" \u00b7 Reserve ").append(Fmt.money(item.reservePrice)).append(met ? " met" : " not met");
        }
        tvBids.setText(bids.toString());
        updateCountdown();

        // Status line
        String status = null;
        if (ended) {
            if (item.hasBids()) {
                if (iAmLeader()) status = "You won this auction! Message the seller to arrange delivery.";
                else status = "Won by " + (item.currentBidderName == null ? "a bidder" : item.currentBidderName)
                        + (owner ? (item.fulfilled ? " \u00b7 Delivered \u2713" : " \u00b7 Awaiting delivery") : "");
            } else {
                status = "Ended with no bids.";
            }
        } else if (iAmLeader()) {
            status = "You're the highest bidder.";
        }
        if (status == null) {
            tvStatus.setVisibility(View.GONE);
        } else {
            tvStatus.setText(status);
            tvStatus.setVisibility(View.VISIBLE);
        }

        // Bid form
        bidBox.setVisibility(!ended && !owner ? View.VISIBLE : View.GONE);
        tilBid.setHint("Your bid (min " + Fmt.money(Fmt.minNextBid(item)) + ")");

        // Action buttons
        boolean winnerExists = item.hasBids() && item.currentBidderUid != null;
        if (!owner) {
            btnMessage.setVisibility(View.VISIBLE);
            btnMessage.setText("Message seller");
            btnMessage.setOnClickListener(v -> openChat(item.ownerUid, item.ownerName, null));
            btnFeedback.setVisibility(View.VISIBLE);
            if (ended && iAmLeader()) {
                btnSecond.setVisibility(View.VISIBLE);
                btnSecond.setText("Share my delivery details");
                btnSecond.setOnClickListener(v -> openChat(item.ownerUid, item.ownerName, deliveryDetailsTemplate()));
            } else {
                btnSecond.setVisibility(View.GONE);
            }
        } else {
            btnFeedback.setVisibility(View.GONE);
            if (ended && winnerExists) {
                btnMessage.setVisibility(View.VISIBLE);
                btnMessage.setText("Message winner");
                btnMessage.setOnClickListener(v -> openChat(item.currentBidderUid, item.currentBidderName,
                        "Hi! Congrats on winning \"" + item.title + "\" for " + Fmt.money(item.current())
                                + ". Could you send me your delivery details \u2014 full name, phone number, and address "
                                + "(or preferred pickup spot) \u2014 so I can get this to you?"));
                btnSecond.setVisibility(View.VISIBLE);
                btnSecond.setText(item.fulfilled ? "Mark undelivered" : "Mark delivered");
                btnSecond.setOnClickListener(v -> db.collection("items").document(itemId)
                        .update("fulfilled", !item.fulfilled));
            } else {
                btnMessage.setVisibility(View.GONE);
                btnSecond.setVisibility(View.GONE);
            }
        }

        tvDesc.setText(item.description.isEmpty() ? "No description provided." : item.description);
        tvSeller.setText(item.ownerName.isEmpty() ? "A seller" : item.ownerName + (owner ? " (you)" : ""));
        if (item.contact.isEmpty()) {
            tvContact.setVisibility(View.GONE);
        } else {
            tvContact.setVisibility(View.VISIBLE);
            tvContact.setText("Contact: " + item.contact);
        }

        // Toolbar menu
        Menu menu = toolbar.getMenu();
        MenuItem block = menu.findItem(R.id.action_block);
        MenuItem report = menu.findItem(R.id.action_report);
        MenuItem remind = menu.findItem(R.id.action_remind);
        if (block != null) block.setVisible(!owner);
        if (report != null) report.setVisible(!owner);
        if (remind != null) remind.setVisible(!ended);
        updateWatchIcon();
    }

    private void updateCountdown() {
        if (item == null) return;
        if (item.isEnded()) {
            tvCountdown.setText("Auction ended");
            tvCountdown.setTextColor(Ui.color(this, R.attr.vbMuted));
        } else {
            tvCountdown.setText(Fmt.timeLeft(item.endTime));
            long left = item.endTime - System.currentTimeMillis();
            tvCountdown.setTextColor(Ui.color(this, left < 5 * 60 * 1000L ? R.attr.vbError : R.attr.vbWarn));
        }
    }

    private void updateWatchIcon() {
        MenuItem w = toolbar.getMenu().findItem(R.id.action_watch);
        if (w == null) return;
        boolean on = UserStore.get().saved.contains(itemId);
        w.setIcon(on ? R.drawable.ic_heart : R.drawable.ic_heart_outline);
    }

    private void updatePhotoCounter(int pos) {
        int n = photoAdapter.getItemCount();
        if (n <= 1) return;
        int p = Math.max(0, Math.min(pos, n - 1));
        tvPhotoCount.setText((p + 1) + " / " + n);
    }

    private void renderBids(List<DocumentSnapshot> docs) {
        bidHistory.removeAllViews();
        tvNoBids.setVisibility(docs.isEmpty() ? View.VISIBLE : View.GONE);
        LayoutInflater inf = LayoutInflater.from(this);
        for (DocumentSnapshot d : docs) {
            View row = inf.inflate(R.layout.row_bid, bidHistory, false);
            Object nm = d.get("bidderName");
            Object uid = d.get("bidderUid");
            Object amt = d.get("amount");
            String name = nm instanceof String && !((String) nm).isEmpty() ? (String) nm : "A bidder";
            if (uid instanceof String && uid.equals(me.getUid())) name += " (you)";
            FontStyler.apply(row);
            ((TextView) row.findViewById(R.id.tv_bidder)).setText(name);
            ((TextView) row.findViewById(R.id.tv_bid_amount))
                    .setText(amt instanceof Number ? Fmt.money(((Number) amt).doubleValue()) : "");
            bidHistory.addView(row);
        }
    }

    private void renderFeedback(List<DocumentSnapshot> docs) {
        feedbackList.removeAllViews();
        tvFeedbackHeader.setVisibility(docs.isEmpty() ? View.GONE : View.VISIBLE);
        for (DocumentSnapshot d : docs) {
            Object t = d.get("text");
            Object n = d.get("fromName");
            if (!(t instanceof String)) continue;
            TextView tv = new TextView(this);
            tv.setTextColor(Ui.color(this, R.attr.vbText));
            tv.setTextSize(14);
            tv.setPadding(0, 4, 0, 4);
            tv.setText("\u2728 " + t + (n instanceof String ? "  \u2014 " + n : ""));
            FontStyler.apply(tv);
            feedbackList.addView(tv);
        }
    }

    // ---------------- bidding ----------------

    private void placeBid() {
        if (item == null || placingBid) return;
        if (isOwner()) {
            toast("You can't bid on your own listing.");
            return;
        }
        if (item.isEnded()) {
            toast("This auction has ended.");
            return;
        }
        String s = etBid.getText() == null ? "" : etBid.getText().toString().trim();
        final double amount;
        try {
            amount = Double.parseDouble(s);
        } catch (NumberFormatException e) {
            toast("Enter a bid amount.");
            return;
        }
        if (Double.isNaN(amount) || Double.isInfinite(amount)) {
            toast("Enter a valid bid amount.");
            return;
        }
        double min = Fmt.minNextBid(item);
        if (amount < min) {
            toast("Bid must be at least " + Fmt.money(min) + ".");
            return;
        }

        placingBid = true;
        btnBid.setEnabled(false);
        final String myUid = me.getUid();
        final String myName = bidderName();
        final DocumentReference ref = db.collection("items").document(itemId);
        final DocumentReference bidRef = ref.collection("bids").document();

        // One atomic transaction: re-read the live price, validate, update the item AND append the
        // bid record together. This closes the "two bids read the same price" race the web app has.
        db.runTransaction((Transaction.Function<Boolean>) tx -> {
            DocumentSnapshot snap = tx.get(ref);
            if (!snap.exists()) {
                throw new FirebaseFirestoreException("This listing no longer exists.",
                        FirebaseFirestoreException.Code.ABORTED);
            }
            Item cur = Item.from(snap);
            long now = System.currentTimeMillis();
            if (cur.endTime > 0 && cur.endTime <= now) {
                throw new FirebaseFirestoreException("This auction has just ended.",
                        FirebaseFirestoreException.Code.ABORTED);
            }
            if (cur.ownerUid.equals(myUid)) {
                throw new FirebaseFirestoreException("You can't bid on your own listing.",
                        FirebaseFirestoreException.Code.ABORTED);
            }
            double liveMin = Fmt.minNextBid(cur);
            if (amount < liveMin) {
                throw new FirebaseFirestoreException("Someone just bid - the minimum is now " + Fmt.money(liveMin) + ".",
                        FirebaseFirestoreException.Code.ABORTED);
            }
            boolean extend = cur.endTime > 0 && (cur.endTime - now) < Const.SNIPE_WINDOW_MS;
            long newEnd = extend ? now + Const.SNIPE_WINDOW_MS : cur.endTime;

            Map<String, Object> upd = new HashMap<>();
            upd.put("currentBid", amount);
            upd.put("currentBidderUid", myUid);
            upd.put("currentBidderName", myName);
            upd.put("bidCount", cur.bidCount + 1);
            upd.put("everBidUids", FieldValue.arrayUnion(myUid));
            upd.put("endTime", newEnd);
            tx.update(ref, upd);

            Map<String, Object> bid = new HashMap<>();
            bid.put("bidderUid", myUid);
            bid.put("bidderName", myName);
            bid.put("amount", amount);
            bid.put("at", FieldValue.serverTimestamp());
            tx.set(bidRef, bid);
            return extend;
        }).addOnSuccessListener(extended -> {
            placingBid = false;
            btnBid.setEnabled(true);
            etBid.setText("");
            Ui.haptic(btnBid, true);
            toast(Boolean.TRUE.equals(extended)
                    ? "Bid placed \u2014 auction extended 2 minutes!"
                    : "Bid placed \u2014 you're the highest bidder.");
        }).addOnFailureListener(e -> {
            placingBid = false;
            btnBid.setEnabled(true);
            Ui.haptic(btnBid, false);
            if (e instanceof FirebaseFirestoreException
                    && ((FirebaseFirestoreException) e).getCode() == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                toast("The server rejected that bid. Make sure the latest firestore.rules are published.");
            } else {
                toast(e.getMessage() == null ? "Couldn't place that bid - try again." : e.getMessage());
            }
        });
    }

    private String bidderName() {
        String n = UserStore.get().name;
        if (n != null && !n.isEmpty()) return n;
        String dn = me.getDisplayName();
        return dn != null && !dn.isEmpty() ? dn : "A bidder";
    }

    // ---------------- menu / actions ----------------

    private boolean onMenu(MenuItem m) {
        int id = m.getItemId();
        if (item == null) return true;
        if (id == R.id.action_watch) {
            UserStore.get().setSaved(itemId, !UserStore.get().saved.contains(itemId));
            return true;
        } else if (id == R.id.action_share) {
            shareListing();
            return true;
        } else if (id == R.id.action_remind) {
            addReminder();
            return true;
        } else if (id == R.id.action_report) {
            showReportDialog();
            return true;
        } else if (id == R.id.action_block) {
            confirmBlock();
            return true;
        }
        return false;
    }

    private void shareListing() {
        String text = item.title + " \u2014 currently " + Fmt.money(item.current()) + " on VeusBid"
                + (item.code.isEmpty() ? "" : " (listing " + item.code + ")");
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(send, "Share listing"));
    }

    private void addReminder() {
        Intent i = new Intent(Intent.ACTION_INSERT)
                .setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, "VeusBid ends: " + item.title)
                .putExtra(CalendarContract.Events.DESCRIPTION,
                        "Current bid " + Fmt.money(item.current()) + ". Listing " + item.code)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, item.endTime)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, item.endTime + 15 * 60 * 1000L);
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast("No calendar app found on this device.");
        }
    }

    private void showReportDialog() {
        final EditText input = new EditText(this);
        input.setHint("What's the issue with this listing?");
        input.setTextColor(Ui.color(this, R.attr.vbText));
        input.setHintTextColor(Ui.color(this, R.attr.vbMuted));
        input.setMaxLines(4);
        int pad = Math.round(20 * getResources().getDisplayMetrics().density);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        new MaterialAlertDialogBuilder(this)
                .setTitle("Report listing")
                .setView(box)
                .setPositiveButton("Send report", (d, w) -> {
                    String reason = input.getText().toString().trim();
                    Map<String, Object> r = new HashMap<>();
                    r.put("reportedItemId", itemId);
                    r.put("reportedUid", item.ownerUid);
                    r.put("reporterUid", me.getUid());
                    r.put("reason", reason.isEmpty() ? "No reason given" : reason);
                    r.put("createdAt", FieldValue.serverTimestamp());
                    db.collection("reports").add(r)
                            .addOnSuccessListener(x -> toast("Report sent - thank you."))
                            .addOnFailureListener(e -> toast("Couldn't send the report - try again."));
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmBlock() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Block this seller?")
                .setMessage("Their listings will be hidden from Browse. You can undo this in Account.")
                .setPositiveButton("Block", (d, w) -> {
                    UserStore.get().block(item.ownerUid);
                    toast("Seller blocked.");
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showFeedbackPicker() {
        if (item == null) return;
        new MaterialAlertDialogBuilder(this)
                .setTitle("Leave feedback")
                .setItems(Const.FEEDBACK_PRESETS, (d, which) -> sendFeedback(Const.FEEDBACK_PRESETS[which]))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void sendFeedback(String text) {
        Map<String, Object> f = new HashMap<>();
        f.put("itemId", itemId);
        f.put("ownerUid", item.ownerUid);
        f.put("itemName", item.title.isEmpty() ? "a listing" : item.title);
        f.put("fromUid", me.getUid());
        f.put("fromName", bidderName());
        f.put("text", text);
        f.put("createdAt", FieldValue.serverTimestamp());
        db.collection("feedback").add(f)
                .addOnSuccessListener(x -> toast("Feedback posted."))
                .addOnFailureListener(e -> toast("Couldn't post that - try again."));
    }

    private String deliveryDetailsTemplate() {
        UserStore us = UserStore.get();
        StringBuilder sb = new StringBuilder();
        sb.append("Hi! I won \"").append(item.title).append("\" for ").append(Fmt.money(item.current()))
                .append(". Here are my delivery details:\n");
        sb.append("Name: ").append(us.name == null ? "" : us.name).append("\n");
        sb.append("Phone: ").append(us.phone == null ? "" : us.phone).append("\n");
        sb.append("Address / pickup spot: ");
        return sb.toString();
    }

    private void openChat(String otherUid, String otherName, String prefill) {
        if (otherUid == null || otherUid.isEmpty()) {
            toast("That member isn't available.");
            return;
        }
        Intent i = new Intent(this, ChatActivity.class);
        i.putExtra(Const.EXTRA_OTHER_UID, otherUid);
        i.putExtra(Const.EXTRA_OTHER_NAME, otherName == null ? "" : otherName);
        if (prefill != null) i.putExtra(Const.EXTRA_PREFILL, prefill);
        startActivity(i);
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }

    // ---------------- photo pager ----------------

    private static final class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.VH> {
        private final List<String> data = new ArrayList<>();

        boolean sameAs(List<String> other) {
            return data.equals(other);
        }

        void set(List<String> photos) {
            data.clear();
            data.addAll(photos);
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_photo, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            ImageUtil.load((ImageView) h.itemView, data.get(position), 900);
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        static final class VH extends RecyclerView.ViewHolder {
            VH(View v) {
                super(v);
            }
        }
    }
}
